-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 13, 2020 at 08:51 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `farmer`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `Address_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `line1` varchar(100) NOT NULL,
  `line2` varchar(100) NOT NULL,
  `Land_mark` varchar(100) NOT NULL,
  `City_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`Address_id`, `user_id`, `line1`, `line2`, `Land_mark`, `City_id`) VALUES
(1, 1, 'D.No:1-88-25, plot no:148', 'sector-4, MVP Colony', 'Opp HMTV Channel', 1);

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Admin_id` int(11) NOT NULL,
  `Admin_User_Name` varchar(30) NOT NULL,
  `Admin_Password` varchar(30) NOT NULL,
  `Phone_no` varchar(11) NOT NULL,
  `Email_Id` varchar(50) NOT NULL,
  `line1` varchar(100) NOT NULL,
  `line2` varchar(100) NOT NULL,
  `Land_mark` varchar(100) NOT NULL,
  `City_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Admin_id`, `Admin_User_Name`, `Admin_Password`, `Phone_no`, `Email_Id`, `line1`, `line2`, `Land_mark`, `City_id`) VALUES
(1, 'admin', 'admin@123', '9885666241', 'savvyitsols@gmail.com', 'sector- 4', 'MVP Colony', 'Opp HMTV Channel', 1),
(2, 'surya', 'Surya@123', '987654321', 'surya.prasad@gmail.com', '1-2-3', 'Sujtha Nagar', 'Near Shopping Mall', 1);

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `City_id` int(11) NOT NULL,
  `City_code` varchar(4) NOT NULL,
  `City` varchar(20) NOT NULL,
  `City_map` text NOT NULL,
  `State_Id` int(11) NOT NULL,
  `Country_Id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`City_id`, `City_code`, `City`, `City_map`, `State_Id`, `Country_Id`) VALUES
(1, 'VSKP', 'VISAKHAPATNAM', '27f6b9c82b3250430165fcd088065820anantpur-tehsil-map.jpg', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `contact_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `contactType_id` int(11) NOT NULL,
  `value` varchar(20) NOT NULL,
  `hours` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`contact_id`, `user_id`, `contactType_id`, `value`, `hours`) VALUES
(1, 1, 1, '9885666241', '9am to 7PM');

-- --------------------------------------------------------

--
-- Table structure for table `contacttype`
--

CREATE TABLE `contacttype` (
  `contactType_id` int(11) NOT NULL,
  `contacttype` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contacttype`
--

INSERT INTO `contacttype` (`contactType_id`, `contacttype`) VALUES
(1, 'Mobile'),
(2, 'Home'),
(3, 'Business'),
(4, 'Email Id');

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `Country_id` int(11) NOT NULL,
  `Country_code_2` varchar(4) NOT NULL,
  `Country_code_3` varchar(4) NOT NULL,
  `Country` varchar(25) NOT NULL,
  `Flag` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`Country_id`, `Country_code_2`, `Country_code_3`, `Country`, `Flag`) VALUES
(1, 'IN', 'IND', 'INDIA', '7488081cdab45da82e036f7cb9a9ed0d1200px-Flag_of_India.png');

-- --------------------------------------------------------

--
-- Table structure for table `farming`
--

CREATE TABLE `farming` (
  `Farm_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `FarmItem_id` int(11) NOT NULL,
  `farmType_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unitType_id` int(11) NOT NULL,
  `timeframe` varchar(50) NOT NULL,
  `verified` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `farming`
--

INSERT INTO `farming` (`Farm_id`, `user_id`, `FarmItem_id`, `farmType_id`, `quantity`, `unitType_id`, `timeframe`, `verified`) VALUES
(1, 1, 1, 3, 100, 2, '2 sessions', 1),
(3, 1, 3, 2, 100, 5, '3 sessions', 1);

-- --------------------------------------------------------

--
-- Table structure for table `farmitem`
--

CREATE TABLE `farmitem` (
  `FarmItem_id` int(11) NOT NULL,
  `farmitem` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `farmitem`
--

INSERT INTO `farmitem` (`FarmItem_id`, `farmitem`) VALUES
(1, 'Rice'),
(2, 'Tomatoes'),
(3, 'Milk'),
(4, 'Potato');

-- --------------------------------------------------------

--
-- Table structure for table `farmtype`
--

CREATE TABLE `farmtype` (
  `farmType_id` int(11) NOT NULL,
  `farmtype` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `farmtype`
--

INSERT INTO `farmtype` (`farmType_id`, `farmtype`) VALUES
(1, 'Natural-Desi-Seeds'),
(2, 'Natural'),
(3, 'Organic'),
(4, 'Pesticides');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `Login_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `Login_date` date NOT NULL,
  `Login_time` time NOT NULL,
  `Logout_date` date NOT NULL,
  `Logout_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `State_id` int(11) NOT NULL,
  `State_code` varchar(4) NOT NULL,
  `State` varchar(20) NOT NULL,
  `State_map` text NOT NULL,
  `Country_Id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`State_id`, `State_code`, `State`, `State_map`, `Country_Id`) VALUES
(1, 'AP', 'ANDHRA PRADESH', '3016b59c1f3c0397ebe416480ace0c8fMap-of-Andhra-pradesh.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `unittype`
--

CREATE TABLE `unittype` (
  `unitType_id` int(11) NOT NULL,
  `unittype` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `unittype`
--

INSERT INTO `unittype` (`unitType_id`, `unittype`) VALUES
(1, 'Kg'),
(2, 'Qintal'),
(3, 'Tones'),
(4, 'Grams'),
(5, 'Litre');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `Fullname` varchar(50) NOT NULL,
  `User_name` varchar(30) NOT NULL,
  `PWD` varchar(20) NOT NULL,
  `DOB` date NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `offerTraining` tinyint(1) NOT NULL,
  `contactByPhone` tinyint(1) NOT NULL,
  `contactByEmail` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `Fullname`, `User_name`, `PWD`, `DOB`, `enabled`, `offerTraining`, `contactByPhone`, `contactByEmail`) VALUES
(1, 'RAMMURTHY NAIDU BODDU', 'brnaidu', 'naidu123', '1985-08-10', 0, 0, 1, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`Address_id`),
  ADD KEY `user_id` (`user_id`,`City_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Admin_id`),
  ADD KEY `City_id` (`City_id`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`City_id`),
  ADD KEY `State_Id` (`State_Id`),
  ADD KEY `Country_Id` (`Country_Id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`contact_id`),
  ADD KEY `user_id` (`user_id`,`contactType_id`);

--
-- Indexes for table `contacttype`
--
ALTER TABLE `contacttype`
  ADD PRIMARY KEY (`contactType_id`);

--
-- Indexes for table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`Country_id`);

--
-- Indexes for table `farming`
--
ALTER TABLE `farming`
  ADD PRIMARY KEY (`Farm_id`),
  ADD KEY `user_id` (`user_id`,`FarmItem_id`,`farmType_id`,`unitType_id`);

--
-- Indexes for table `farmitem`
--
ALTER TABLE `farmitem`
  ADD PRIMARY KEY (`FarmItem_id`);

--
-- Indexes for table `farmtype`
--
ALTER TABLE `farmtype`
  ADD PRIMARY KEY (`farmType_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`Login_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`State_id`),
  ADD KEY `Country_Id` (`Country_Id`);

--
-- Indexes for table `unittype`
--
ALTER TABLE `unittype`
  ADD PRIMARY KEY (`unitType_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `Address_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `City_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contacttype`
--
ALTER TABLE `contacttype`
  MODIFY `contactType_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
  MODIFY `Country_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `farming`
--
ALTER TABLE `farming`
  MODIFY `Farm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `farmitem`
--
ALTER TABLE `farmitem`
  MODIFY `FarmItem_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `farmtype`
--
ALTER TABLE `farmtype`
  MODIFY `farmType_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `Login_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `State_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `unittype`
--
ALTER TABLE `unittype`
  MODIFY `unitType_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
