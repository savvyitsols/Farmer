<?php 



$username = "root";
$password = "";
$hostname = "localhost";
$dbname="farmer";
$connect=mysqli_connect($hostname, $username, $password,$dbname) or die("Error " . mysqli_error($connect));


?>