<?php ob_start();
session_start();
error_reporting(0);
include "../config.php";
include "secure.php";
include "pageing.php";
extract($_POST);
extract($_GET);
date_default_timezone_set('Asia/Calcutta');

?>
<!DOCTYPE html>
<html lang="en">
  

<head>
    <meta charset="utf-8">
    
    <link rel="shortcut icon" href="img/favicon.html">

    <title>Medserv.in</title>

    <!-- Bootstrap core CSS -->
 <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />

    
    
     <link rel="stylesheet" type="text/css" href="assets/bootstrap-datepicker/css/datepicker.css" />
    <link rel="stylesheet" type="text/css" href="assets/bootstrap-timepicker/compiled/timepicker.css" />
    <link rel="stylesheet" type="text/css" href="assets/bootstrap-colorpicker/css/colorpicker.css" />
    <link rel="stylesheet" type="text/css" href="assets/bootstrap-daterangepicker/daterangepicker-bs3.css" />
    <link rel="stylesheet" type="text/css" href="assets/bootstrap-datetimepicker/css/datetimepicker.css" />
  
    
      <!--right slidebar-->
      <link href="css/slidebars.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />

 	<link rel="stylesheet" href="assets/dist/css/bootstrap-select.css">
    
    

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
	<script type="text/javascript">
	function changeGraph(s,Doctor_id) {
		
	  if (window.XMLHttpRequest) {
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	  } else {  // code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	  xmlhttp.onreadystatechange=function() {
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
		  document.getElementById("graphId").innerHTML=xmlhttp.responseText;
		  
		}
	  }
	  
	  xmlhttp.open("GET","graph_ajax.php?Hospital_id="+s+"&Doctor_id="+Doctor_id,true);
	 
	  xmlhttp.send();
	}
	</script>

	<script type="text/javascript">
	function valid()
	{
		if(document.getElementById("Doctor_id").value=='' && document.getElementById("from_date").value=='' && document.getElementById("to_date").value=='' && document.getElementById("Status_id").value=='')
		{
			alert("Please Select Any One");
			document.getElementById("Doctor_id").focus();
			return false;
			
		}
		else if(document.getElementById("from_date").value=='' && document.getElementById("to_date").value!='')
		{
			alert("Please Select From Date");
			document.getElementById("from_date").focus();
			return false;
		}
		else if(document.getElementById("from_date").value!='' && document.getElementById("to_date").value=='')
		{
			alert("Please Select To Date");
			document.getElementById("to_date").focus();
			return false;
		}
		return true;
	}
	</script>
  </head>

  <body>

  <section id="container" >
      <!--header start-->
      <?php include "header.php"; ?>
      <!--header end-->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <?php include "sidemenu.php"; ?>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <!--state overview start-->
              
              <div class="row">
                  <div class="col-lg-12">
                      <!--breadcrumbs start -->
                      <ul class="breadcrumb">
                          <li><a href="#"><i class="fa fa-home"></i> Reports</a></li>
                         
                      </ul>
                      <!--breadcrumbs end -->
                  </div>
              </div>
              
              <div class="row">
              	<div class="col-lg-12">
                	<section class="panel">
                    <form name="form1" method="get" action="" onSubmit="return valid();">
                    	<div class="panel-body">
                        	<div class="col-lg-12" style="float:right; text-align:right">
                            	<input type="submit" name="Search" value="Search" class="btn btn-success">
                            </div>
                        	<div class="col-lg-3">
                            	<div class="form-group">
                                	<label class="control-label">Doctor</label>
                                    <select  class="selectpicker form-control"  data-live-search="true" name="Doctor_id" id="Doctor_id" >
                                        <option value="">Select Doctor</option>
                                        <?php
                                        $doc_qry=mysqli_query($connect,"SELECT * FROM `doctor` ORDER BY `Doctor_name` ASC");
                                        while($doc_qry_row=mysqli_fetch_assoc($doc_qry))
                                        {
                                            ?>
                                            <option value="<?php echo $doc_qry_row['Doctor_id']; ?>"><?php echo $doc_qry_row['Doctor_name']; ?></option>
                                            <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3">
                            	<div class="form-group">
                                	<div data-date-viewmode="years" data-date-format="dd-mm-yyyy" data-date="<?php echo date('d-m-Y'); ?>"  class="input-append date dpYears">
                                    	<label class="control-label">From Date</label>
                                        <input class="form-control"  size="16" type="text" placeholder="Select From Date" name="from_date" id="from_date"  />
                                        <span class="input-group-btn add-on"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3">
                            	<div class="form-group">
                                	<div data-date-viewmode="years" data-date-format="dd-mm-yyyy" data-date="<?php echo date('d-m-Y'); ?>"  class="input-append date dpYears">
                                    	<label class="control-label">To Date</label>
                                        <input class="form-control"  size="16" type="text" placeholder="Select To Date" name="to_date" id="to_date"  />
                                        <span class="input-group-btn add-on"></span>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-lg-3">
                            	<div class="form-group">
                                	<label class="control-label">Status</label>
                                    <select  class="form-control" name="Status_id" id="Status_id" >
                                        <option value="">Select Status</option>
                                        <?php
                                        $stat_qry=mysqli_query($connect,"SELECT * FROM `bookings_status` ORDER BY `Booking_status_id` ASC");
                                        while($stat_qry_row=mysqli_fetch_assoc($stat_qry))
                                        {
                                            ?>
                                            <option value="<?php echo $stat_qry_row['Booking_status_id']; ?>"><?php echo $stat_qry_row['Status']; ?></option>
                                            <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                      </form>
                    </section>
                </div>
           	  </div>
              <section class="panel">
                          
                          <div class="panel-body">
                              <div class="tab-content">
                                  <div id="today" class="tab-pane active">
                                  	
                                   <?php
								   $limit = 10; 								
									if(isset($page)) 
									$start = ($page - 1) * $limit; 			
									else
									$start = 0;						
									$filePath="Reports.php";
									if(isset($_GET) && $_GET['Search']=="Search")
									{
										$var='';
										$text='<font size="+1">Total Appointments ';
										if($Doctor_id!='')
										{
											$doc=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `doctor` WHERE `Doctor_id`='$Doctor_id'"));
											$var.="b.Doctor_id=$Doctor_id AND ";
											$text.=' For '.$doc['Doctor_name'];	
										}
										if($from_date!='' && $to_date!='')
										{
											//$from_date_search=date('Y-m-d',strtotime($from_date))." 00:00:00";	
											//$to_date_search=date('Y-m-d',strtotime($to_date))." 59:59:59";	
											
											$from_date_search=date('Y-m-d',strtotime($from_date));	
											$to_date_search=date('Y-m-d',strtotime($to_date));	
											$var.=" (b.Book_Appointment_Time BETWEEN '$from_date_search' AND '$to_date_search') AND ";
											$text.=' Between '.$from_date.' AND '.$to_date;
										}
										if($Status_id!='')
										{
											$sta=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `bookings_status` WHERE `Booking_status_id`='$Status_id'"));
											$var.="b.Status_id=$Status_id AND ";
											$text.=' For '.$sta['Status'];
										}
										$select="SELECT * FROM bookings b,doctor d,	patient p,bookings_status bs WHERE  $var b.Doctor_id=d.Doctor_id AND b.patients_id=p.patient_id AND b.Status_id=bs.Booking_status_id Limit $start, $limit ";
										 $select1="SELECT * FROM bookings b,doctor d,patient p,bookings_status bs WHERE  $var b.Doctor_id=d.Doctor_id AND b.patients_id=p.patient_id  AND b.Status_id=bs.Booking_status_id";
										
										$otherParams="Search=$Search&Doctor_id=$Doctor_id&from_date=$from_date&to_date=$to_date&Status_id=$Status_id";
										$result=mysqli_query($connect,$select);
										$total=mysqli_num_rows(mysqli_query($connect,$select1));	
										$text.=': '.$total.'</font>';
									}
									else
									{
										$select="SELECT * FROM bookings b,doctor d,	patient p,bookings_status bs WHERE b.Doctor_id=d.Doctor_id AND b.patients_id=p.patient_id AND b.Status_id=bs.Booking_status_id Limit $start, $limit ";
										$select1="SELECT * FROM bookings b,doctor d,patient p,bookings_status bs WHERE b.Doctor_id=d.Doctor_id AND b.patients_id=p.patient_id  AND b.Status_id=bs.Booking_status_id";
										
										$otherParams="";	
										$result=mysqli_query($connect,$select);
										$total=mysqli_num_rows(mysqli_query($connect,$select1));
										$text='<font size="+1">Total Appointments :'.$total.'</font>';
									}
									
									?>  
                                    
                                    <div class="col-lg-12" style="text-align:right">
                                    	<?php echo $text; ?>
                                    </div> 
                                   
                                   <table class="table table-advance table-bordered table-hover">
                                      <thead>
                                          <tr>
                                          	<th width="6%">S.No</th>
                                            <th width="18%">Doctor Name</th>
                                            <th width="18%">Patient Name</th>
                                            <th width="18%">Appointment Time</th>
                                           
                                            <th width="19%">Status</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                       <?php
									   	
										if($total==0)
										{
											   ?>
											   <tr>
													<td colspan="10" align="center"><font color="#FF0000"><strong>No Appointments</strong></font></td>
											   </tr>
											   <?php
										}
									   else
									   {
										   $m=$start+1;
										   while($row=mysqli_fetch_assoc($result))
										   {
											   ?>
                                               <tr>
                                               		<td><?php echo $m; ?></td>
                                                    <td><?php echo $row['Doctor_name']; ?></td>
                                                    <td><?php echo $row['patient_name']; ?></td>
                                                    <td><?php echo $row['Book_Appointment_Time']; ?></td>
                                                   
                                                    <td><?php echo $row['Status']; ?></td>
                                               </tr>
                                               <?php
											   $m++;
										   }
										
										if($total>$limit)
										{
											?>
                                            <tr>
                                            <td colspan="10"> 
                                           <div class="row"><div class="col-lg-12" style="text-align:left"><?php make_pages($page,$limit,$total,$filePath,$otherParams); ?></div></div>
                                           </td>
                                           </tr>
                                            <?php
										}
				
									   }
									   ?>
                                        </tbody>
                                     </table>

                                  </div>
                                
                              </div>
                          </div>
                      </section>
              
              
            
              <!--state overview end-->

              
              
              
              

          </section>
      </section>
      <!--main content end-->


      <!--footer start-->
      <footer class="site-footer">
          <?php include "footer.php"; ?>
      </footer>
      <!--footer end-->
  </section>

  <!-- js placed at the end of the document so the pages load faster -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/jquery-ui-1.9.2.custom.min.js"></script>
  

  <script class="include" type="text/javascript" src="js/jquery.dcjqaccordion.2.7.js"></script>
  <script src="js/jquery.scrollTo.min.js"></script>
  <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
  <script src="js/respond.min.js" ></script>

  <!--right slidebar-->
  <script src="js/slidebars.min.js"></script>

	
  
  <script src="assets/dist/js/bootstrap-select.js"></script>
  
  <script type="text/javascript" src="assets/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
  <script type="text/javascript" src="assets/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"></script>
  <script type="text/javascript" src="assets/bootstrap-daterangepicker/moment.min.js"></script>
  <script type="text/javascript" src="assets/bootstrap-daterangepicker/daterangepicker.js"></script>
  <script type="text/javascript" src="assets/bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script>
  <script type="text/javascript" src="assets/bootstrap-timepicker/js/bootstrap-timepicker.js"></script>

  
  <script src="js/common-scripts.js"></script>
  <script src="js/advanced-form-components.js"></script>
  

  <script>

      //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true,
			  autoPlay:true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>

<!-- Mirrored from thevectorlab.net/flatlab/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Nov 2014 04:49:40 GMT -->
</html>
