<?php
include "../config.php";
extract($_POST);
extract($_GET);
$doctor=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `doctor` WHERE `Doctor_id`='$Doctor_id'"));
$sql=mysqli_query($connect,"SELECT * FROM `qualification` WHERE `Qualification_id`!='$doctor[qualification]'");

?>
<select name="Qualification_id" id="Qualification_id" class="form-control" required>
<option value=""> - Select Qualification - </option>
<?php

while($sql_row=mysqli_fetch_assoc($sql))
{
?>

<option value='<?php echo $sql_row["Qualification_id"]; ?>'> <?php echo $sql_row["Qualification"]; ?> </option>
<?php } ?>
</select>