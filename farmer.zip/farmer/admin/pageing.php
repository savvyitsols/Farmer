

<?php


function make_pages($page,$limit,$total,$filePath,$otherParams)

{

	@$divs=$total%$limit;

	if($divs==0)

	{

	@$tots=(int)($total/$limit);

	}else{

	@$tots=(int)($total/$limit) + 1;

	}
	echo "<ul class='pagination'>";
	echo "<li><a href=\"$filePath?page=".(1)."&$otherParams\">[First]</a></li>&nbsp;&nbsp;";

	if($tots==1)

	{

	echo "<li><a href=\"$filePath?page=1&$otherParams\" >[1]</a></li>&nbsp;&nbsp;";

	}

	if($tots>1)

	{

		if($page>1)

		{

		echo "<li><a href=\"$filePath?page=".($page-1)."&$otherParams\"><< previous</a></li>&nbsp;&nbsp;";

		}
		

		
if(!empty($page))
{

if(($page-5)>=1)
{
echo "<li><a href=\"$filePath?page=".($page-5)."&$otherParams\" >".($page-5)."</a></li>&nbsp;&nbsp;";
}

if(($page-4)>=1)
{
echo "<li><a href=\"$filePath?page=".($page-4)."&$otherParams\" >".($page-4)."</a></li>&nbsp;&nbsp;";
}

if(($page-3)>=1)
{
echo "<li><a href=\"$filePath?page=".($page-3)."&$otherParams\" >".($page-3)."</a></li>&nbsp;&nbsp;";
}

if(($page-2)>=1)
{
echo "<li><a href=\"$filePath?page=".($page-2)."&$otherParams\" >".($page-2)."</a></li>&nbsp;&nbsp;";
}
if(($page-1)>=1)
{
echo "<li><a href=\"$filePath?page=".($page-1)."&$otherParams\" >".($page-1)."</a></li>&nbsp;&nbsp;";
}
echo "<li><a href=\"$filePath?page=$page&$otherParams\"  class='current'  >[$page]</a></li>&nbsp;&nbsp;";

if(($page+1)<=$tots)
{
echo "<li><a href=\"$filePath?page=".($page+1)."&$otherParams\" >".($page+1)."</a></li>&nbsp;&nbsp;";
}
if(($page+2)<=$tots)
{
echo "<li><a href=\"$filePath?page=".($page+2)."&$otherParams\" >".($page+2)."</a></li>&nbsp;&nbsp;";
}
if(($page+3)<=$tots)
{
echo "<li><a href=\"$filePath?page=".($page+3)."&$otherParams\" >".($page+3)."</a></li>&nbsp;&nbsp;";
}
if(($page+4)<=$tots)
{
echo "<li><a href=\"$filePath?page=".($page+4)."&$otherParams\" >".($page+4)."</a></li>&nbsp;&nbsp;";
}
if(($page+5)<=$tots)
{
echo "<li><a href=\"$filePath?page=".($page+5)."&$otherParams\" >".($page+5)."</a></li>&nbsp;&nbsp;";
}
}
else
{
if($tots>3)
{
if(1<=$tots)
{
echo "<li><a href=\"$filePath?page=1&$otherParams\" >1</a></li>&nbsp;&nbsp;";
}
if(2<=$tots)
{
echo "<li><a href=\"$filePath?page=2&$otherParams\" >2</a></li>&nbsp;&nbsp;";
}
if(3<=$tots)
{
echo "<li><a href=\"$filePath?page=3&$otherParams\" >3</a></li>&nbsp;&nbsp;";
}
if(4<=$tots)
{
echo "<li><a href=\"$filePath?page=4&$otherParams\" >4</a></li>&nbsp;&nbsp;";
}
echo ".........";echo "&nbsp;&nbsp;";
if(($tots-3)>=1)
{
echo "<li><a href=\"$filePath?page=".($tots-3)."&$otherParams\" >".($tots-3)."</a></li>&nbsp;&nbsp;";
}
if(($tots-2)>=1)
{
echo "<li><a href=\"$filePath?page=".($tots-2)."&$otherParams\" >".($tots-2)."</a></li>&nbsp;&nbsp;";
}
if(($tots-1)>=1)
{
echo "<li><a href=\"$filePath?page=".($tots-1)."&$otherParams\" >".($tots-1)."</a></li>&nbsp;&nbsp;";
}
echo "<li><a href=\"$filePath?page=".($tots)."&$otherParams\" >".($tots)."</a></li>&nbsp;&nbsp;";
}
else
{
for(@$i=1;$i<=$tots;$i++)
		{
		if($page==$i)
		{
		echo "<li><a href=\"$filePath?page=$i&$otherParams\" class='current' >[$i]</a></li>&nbsp;&nbsp;";
		}else{
		echo "<li><a href=\"$filePath?page=$i&$otherParams\" >$i</a></li>&nbsp;&nbsp;";
		}
		}}
}
}

		if($page<$tots)

		{

		if($page==0 && $tots>1)

		{

		echo "<li><a href=\"$filePath?page=".($page+1+1)."&$otherParams\">next >></a></li>&nbsp;&nbsp;";

		}else{
if($tots>1)
{
		echo "<li><a href=\"$filePath?page=".($page+1)."&$otherParams\">next >></a></li>&nbsp;&nbsp;";
}
		}

		

	
	}

	echo "<li><a href=\"$filePath?page=".($tots)."&$otherParams\">[Last]</a></li>&nbsp;&nbsp;";


echo "</ul>";

}

?>