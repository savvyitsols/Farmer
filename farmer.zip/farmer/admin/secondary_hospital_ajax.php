<?php
include "../config.php";
extract($_POST);
extract($_GET);
$doctor=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `doctor` WHERE `Doctor_id`='$Doctor_id'"));
$sql=mysqli_query($connect,"SELECT * FROM `hospital` WHERE `hospital_id`!='$doctor[Primary_Hospital_Id]'");
?>
<select name="Hospital_id" id="Hospital_id" class="form-control" required>
<option value=""> - Select Hospital - </option>
<?php

while($sql_row=mysqli_fetch_assoc($sql))
{
	
?>

<option value='<?php echo $sql_row["hospital_id"]; ?>'> <?php echo $sql_row["hospital_name"]; ?> </option>
<?php  } ?>
</select>