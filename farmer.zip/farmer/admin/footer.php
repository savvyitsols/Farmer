<div class="text-center">
              2020 &copy; Farmer
              <a href="#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>