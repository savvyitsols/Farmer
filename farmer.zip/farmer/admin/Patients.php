<?php ob_start();
session_start();
error_reporting(0);
include "../config.php";
include "secure.php";
include "pageing.php";
extract($_POST);
extract($_GET);
$date=date('Y-m-d H:i:s');

?>
<!DOCTYPE html>
<html lang="en">
  

<head>
    <meta charset="utf-8">
    
    <link rel="shortcut icon" href="img/favicon.html">

    <title>Medserv.in</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />

    <!--dynamic table-->
    <link href="assets/advanced-datatable/media/css/demo_page.css" rel="stylesheet" />
    <link href="assets/advanced-datatable/media/css/demo_table.css" rel="stylesheet" />
    <link rel="stylesheet" href="assets/data-tables/DT_bootstrap.css" />
      <!--right slidebar-->
      <link href="css/slidebars.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
    <script type="text/javascript">
function delete1()
{
  if(window.confirm("Confirm delete"))
  {
  return true;
   }
 else
   return false;
}

function displayInsurance(s)
{
	
	if(s==1)
	{
		document.getElementById("ins_display").style.display='';
	}
	else
	{
		document.getElementById("ins_display").style.display='none';
	}
}
</script>
  </head>

  <body>

  <section id="container" class="">
      <!--header start-->
      <?php include "header.php"; ?>
      <!--header end-->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <?php include "sidemenu.php"; ?>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <!-- page start-->
              <?php
			if(isset($_GET) && $_GET['action']=="delete")
			  {
				  	$deleted_query=mysqli_query($connect,"DELETE FROM `patient` WHERE `patient_id`='$id'");
					if(isset($deleted_query))
					{
						header("location:Patients.php?delete=yes");
					}
					else
					{
						header("location:Patients.php?delete=no");
					}
			  }
			  else
			  {
			  ?>
              <?php
				if(isset($insert))
				{
					?>
				
					<div class="row">
						<div class="col-lg-4">
						&nbsp;
						</div>
						<div class="col-lg-4" style="text-align:center">                       
							<?php
							if($insert=="yes")
							{
								?>
									<div class="alert alert-success  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Successfully Inserted.
									 </div>
                                <?php
							}
							else
							{
								?>
									<div class="alert alert-danger  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Insertion Operation Failed.
                                    </div>
                                <?php
							}
							?>
								 
						</div>
						<div class="col-lg-4">
						&nbsp;
						</div>
					</div>
					<?php 
					} 
					?>
                     <?php
				if(isset($update))
				{
					?>
				
					<div class="row">
						<div class="col-lg-4">
						&nbsp;
						</div>
						<div class="col-lg-4" style="text-align:center">                       
							<?php
							if($update=="yes")
							{
								?>
									<div class="alert alert-success  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Successfully Updated.
									 </div>
                                <?php
							}
							else
							{
								?>
									<div class="alert alert-danger  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Update Operation Failured.
                                    </div>
                                <?php
							}
							?>
								 
						</div>
						<div class="col-lg-4">
						&nbsp;
						</div>
					</div>
					<?php 
					} 
					?>
                     <?php
				if(isset($delete))
				{
					?>
				
					<div class="row">
						<div class="col-lg-4">
						&nbsp;
						</div>
						<div class="col-lg-4" style="text-align:center">                       
							<?php
							if($delete=="yes")
							{
								?>
									<div class="alert alert-success  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Successfully  Deleted.
									 </div>
                                <?php
							}
							else
							{
								?>
									<div class="alert alert-danger  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Delete Operation Failed.
                                    </div>
                                <?php
							}
							?>
								 
						</div>
						<div class="col-lg-4">
						&nbsp;
						</div>
					</div>
					<?php 
					} 
					?>
              <div class="row">
                <div class="col-sm-12">
              <section class="panel">
              <header class="panel-heading">
                  List Of Patients
             <span class="tools pull-right">
                <a href="javascript:;" class="fa fa-chevron-down"></a>
                <a href="javascript:;" class="fa fa-times"></a>
             </span>
              </header>
              <div class="panel-body">
              <div class="adv-table">
              <table  class="display table table-bordered table-striped" id="dynamic-table">
              <thead>
              <tr>
                    <th>S.No</th>
                    <th >Id</th>
                    <th >Patient Name</th>
                    <th >Email ID</th>
                    <th>Phone Number</th>
                    <th>Gender</th>
                    <th>Date of Birth</th>
                    <th>Date of Anniversary</th>
                    <th>Land Mark</th>
                    
                    <th>Datails Registration</th>
                    
                    
                  
                    <th >Edit</th>
                    <th >Delete</th>
              </tr>
              </thead>
              <tbody>
              	<?php
				$sql_query=mysqli_query($connect,"SELECT * FROM `patient`");
				$total=mysqli_num_rows($sql_query);
				if($total==0)
				{
					?>
                    <tr>
                    	<td colspan="10" align="center">
                        	<font color="#FF0000"><strong>No Records</strong></font>
                        </td>
                    </tr>
                    <?php
				}
				else
				{
					$m=1;
					while($row=mysqli_fetch_array($sql_query))
					{				
						?>
                        <tr>
                           <td><?php echo $m; ?>
                           <td><?php echo $row['Patient_Unique_id']; ?></td>
                           <td><?php echo $row['patient_name']; ?></td>
                            <td><?php echo $row['emailid']; ?></td>
                            <td><?php echo $row['Phone_number']; ?></td>
                            <td><?php echo $row['Gender']; ?></td>
                            <td><?php echo $row['DOB']; ?></td>
                            <td><?php echo $row['Date_Anniversary']; ?></td>
                            <td><?php echo $row['Land_mark']; ?></td>
                            <td><?php echo $row['date_registration']; echo "<br>";  echo $row['time_registration']; echo "<br>"; echo $row['ip'];  ?>(IP)</td>
                       
                           
                            <td><a href="Patients.php?action=edit&id=<?php echo $row['patient_id']; ?>"><button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button></a></td>
                            <td><a href="Patients.php?action=delete&id=<?php echo $row['patient_id']; ?>" onClick="return delete1();"><button class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i></button></a></td>
                        </tr>
                        <?php
						$m++;
					}
                	
				}
				?>
              </tbody>
              </table>
              </div>
              </div>
              </section>
              </div>
              </div>
              <?php 
			  }
			  ?>
              
              <!-- page end-->
          </section>
      </section>
      <!--main content end-->
      
      <!--footer start-->
      <footer class="site-footer" >
         <?php include "footer.php"; ?>
      </footer>
      <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->

    <script src="js/jquery.js"></script>
    <script src="js/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
    <script type="text/javascript" language="javascript" src="assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
    <script type="text/javascript" src="assets/data-tables/DT_bootstrap.js"></script>
    <script src="js/respond.min.js" ></script>

    <!--right slidebar-->
    <script src="js/slidebars.min.js"></script>

    <!--dynamic table initialization -->
    <script src="js/dynamic_table_init.js"></script>


    <!--common script for all pages-->
    <script src="js/common-scripts.js"></script>

  </body>

<!-- Mirrored from thevectorlab.net/flatlab/dynamic_table.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Nov 2014 04:52:22 GMT -->
</html>
