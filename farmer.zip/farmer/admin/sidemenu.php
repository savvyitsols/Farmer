<ul class="sidebar-menu" id="nav-accordion">
                  <li>
                      <a class="active" href="admin_home.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Dashboard</span>
                      </a>
                  </li>

                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-laptop"></i>
                          <span>User</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="user.php">Manage Users</a></li>
                          <li><a  href="user.php?action=add">Add User</a></li>
                          
                      </ul>
                  </li>
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-laptop"></i>
                          <span>Farming</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="farming.php">Manage Farming</a></li>
                          <li><a  href="farming.php?action=add">Add Farming</a></li>
                      </ul>
                  </li>
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-laptop"></i>
                          <span>Farming Item</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="Farmingitem_List.php">Manage Farming Item</a></li>
                          <li><a  href="Farmingitem_List.php?action=add">Add Farming item </a></li>
                      </ul>
                  </li>
				          <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-laptop"></i>
                          <span>Farming Type</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="Farmingtype_List.php">Manage Farming Type</a></li>
                          <li><a  href="Farmingtype_List.php?action=add">Add Farming Type </a></li>
                      </ul>
                  </li>
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-laptop"></i>
                          <span>Unit Type</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="Unittype_List.php">Manage Unit Type</a></li>
                          <li><a  href="Unittype_List.php?action=add">Add Unit Type</a></li>
                      </ul>
                  </li>
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-laptop"></i>
                          <span>Contact Type</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="Contacttype_List.php">Manage Contact Type</a></li>
                          <li><a  href="Contacttype_List.php?action=add">Add Contact Type</a></li>
                      </ul>
                  </li>
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-laptop"></i>
                          <span>Reports</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="Reports.php">Reports</a></li>
                       
                      </ul>
                  </li>
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-sitemap"></i>
                          <span>Others</span>
                      </a>
                      <ul class="sub">
                          
                          <li class="sub-menu">
                              <a  href="#">Country</a>
                              <ul class="sub">
                                  <li><a  href="Country_List.php?action=add">Add Country</a></li>
                                  <li><a  href="Country_List.php">Manage Countries</a></li>
                              </ul>
                          </li>
						  
						  <li class="sub-menu">
                              <a  href="#">State</a>
                              <ul class="sub">
                                  <li><a  href="State_List.php?action=add">Add State</a></li>
                                  <li><a  href="State_List.php">Manage States</a></li>
                              </ul>
                          </li>
						  
						  <li class="sub-menu">
                              <a  href="#">City</a>
                              <ul class="sub">
                                  <li><a  href="City_List.php?action=add">Add City</a></li>
                                  <li><a  href="City_List.php">Manage Cities</a></li>
                              </ul>
                          </li>
              
				</ul>
        <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-laptop"></i>
                          <span>Admin</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="admin.php">Manage Admin</a></li>
                          <li><a  href="admin.php?action=add">Add Admin</a></li>
                      </ul>
                  </li>