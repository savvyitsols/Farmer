<?php
if($_SESSION['Admin_id']=='')
{
	header("location:index.php");
}
?>