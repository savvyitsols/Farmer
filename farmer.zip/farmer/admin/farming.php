<?php ob_start();
session_start();
error_reporting(0);
include "../config.php";
include "secure.php";
include "pageing.php";
extract($_POST);
extract($_GET);
$date=date('Y-m-d H:i:s');
if(isset($_POST) && $_POST['Submit']=="Add")
{
	
	$insert=mysqli_query($connect,"INSERT INTO `farming` (`user_id`,`FarmItem_id`, `farmType_id`, `quantity`, `unitType_id`, `timeframe`, `verified`) VALUES ('$user_id','$FarmItem_id', '$farmType_id', '$quantity', '$unitType_id', '$timeframe', '$verified')");
	
	if($insert)
	{
		 header("location:farming.php?insert=yes");
	}
	else
	{
		header("location:farming.php?insert=no");
	}
}
if(isset($_POST) && $_POST['Submit']=="Update")
{
	$update_query=mysqli_query($connect,"UPDATE `farming` SET `user_id`='$user_id', `FarmItem_id`='$FarmItem_id', `farmType_id`='$farmType_id', `quantity`='$quantity', `unitType_id`='$unitType_id', `timeframe`='$timeframe', `verified`='$verified' WHERE `Farm_id`='$id'");
	if(isset($update_query))
	{
		header("location:farming.php?update=yes");
	}
	else
	{
		header("location:farming.php?update=no");
	}
}
?>
<!DOCTYPE html>
<html lang="en">
  

<head>
    <meta charset="utf-8">
    
    <link rel="shortcut icon" href="img/favicon.html">

    <title>Farmer</title>

    <!-- Bootstrap core CSS -->
      <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />

    <!--dynamic table-->
    <link href="assets/advanced-datatable/media/css/demo_page.css" rel="stylesheet" />
    <link href="assets/advanced-datatable/media/css/demo_table.css" rel="stylesheet" />
    <link rel="stylesheet" href="assets/data-tables/DT_bootstrap.css" />
      <!--right slidebar-->
      <link href="css/slidebars.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
    <script type="text/javascript">
function delete1()
{
  if(window.confirm("Confirm delete"))
  {
  return true;
   }
 else
   return false;
}
</script>
  </head>

  <body>

  <section id="container" class="">
      <!--header start-->
      <?php include "header.php"; ?>
      <!--header end-->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <?php include "sidemenu.php"; ?>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <!-- page start-->
              <?php
			  if(isset($_GET) && $_GET['action']=="add")
			  {
				  ?>
                  <div class="row">
                  <div class="col-lg-8">
                      <section class="panel">
                          <header class="panel-heading">
                             Add New Farming
                             <span class="tools pull-right">
                                
                                 <a href="farming.php" style="color:#00F; font-weight:bold" >Back</a>
                             </span>
                          </header>
                          <div class="panel-body">
                              <form class="form-horizontal tasi-form" method="post" name="add" enctype="multipart/form-data">
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Name of the Farmer</label>
                                      <div class="col-sm-8">
                                         <select name="user_id" class="form-control" required>
                                            <option value=""> - Select Farmer - </option>
                                            <?php
                                            $user_query=mysqli_query($connect,"SELECT * FROM `user`");
                                            while($user_query_row=mysqli_fetch_assoc($user_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $user_query_row["user_id"]; ?>' > <?php echo $user_query_row["Fullname"]; ?> </option>
                                            <?php } ?>
                                          </select>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Name of the Farming Item </label>
                                      <div class="col-sm-8">
                                         <select name="FarmItem_id" class="form-control" required>
                                            <option value=""> - Select Farming Item - </option>
                                            <?php
                                            $farmingitem_query=mysqli_query($connect,"SELECT * FROM `farmitem`");
                                            while($farmingitem_query_row=mysqli_fetch_assoc($farmingitem_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $farmingitem_query_row["FarmItem_id"]; ?>' > <?php echo $farmingitem_query_row["farmitem"]; ?> </option>
                                            <?php } ?>
                                          </select>
                                      </div>
                                  </div>

                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Name of the Farming Type </label>
                                      <div class="col-sm-8">
                                         <select name="farmType_id" class="form-control" required>
                                            <option value=""> - Select Farming Type - </option>
                                            <?php
                                            $farmingtype_query=mysqli_query($connect,"SELECT * FROM `farmtype`");
                                            while($farmingtype_query_row=mysqli_fetch_assoc($farmingtype_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $farmingtype_query_row["farmType_id"]; ?>' > <?php echo $farmingtype_query_row["farmtype"]; ?> </option>
                                            <?php } ?>
                                          </select>
                                      </div>
                                  </div>

                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Quantity </label>
                                      <div class="col-sm-8">
                                          <input  type="text" name="quantity" id="quantity" placeholder=" Quantity " class="form-control" required/>
                                      </div>
                                  </div>
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Units </label>
                                      <div class="col-sm-8">
                                         <select name="unitType_id" class="form-control" required>
                                            <option value=""> - Select Units - </option>
                                            <?php
                                            $unit_query=mysqli_query($connect,"SELECT * FROM `unittype`");
                                            while($unit_query_row=mysqli_fetch_assoc($unit_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $unit_query_row["unitType_id"]; ?>'> <?php echo $unit_query_row["unittype"]; ?> </option>
                                            <?php } ?></select>
                                      </div>
                                  </div>
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Time Frame </label>
                                      <div class="col-sm-8">
                                          <input  type="text" name="timeframe" id="timeframe" placeholder="  Time Frame " class="form-control" required/>
                                      </div>
                                  </div>
                                  

                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">verified </label>
                                      <div class="col-sm-8">
                                         <select name="verified" class="form-control" required>
                                            <option value=""> - Select - </option>
                                            <option value='1' > Yes </option>
                                            <option value='0' > No </option>
                                          </select>
                                      </div>
                                  </div>
                                  
                                 
                                  <div class="form-group">
                                      
                                      <div class="col-sm-4">
                                          &nbsp;
                                      </div>
                                      <div class="col-sm-4">
                                          <input type="submit" name="Submit" value="Add" class="btn btn-success">
                                      </div>
                                      <div class="col-sm-4">
                                          &nbsp;
                                      </div>
                                  </div>
                                  
                                  
                                 
                                 
                              </form>
                          </div>
                      </section>
                   </div>
              </div>
                  
                  <?php
			  }
			  else if(isset($_GET) && $_GET['action']=="edit")
			  {
				  $edit=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `doctor` WHERE `Doctor_id`='$id'"));
				  ?>
				  <div class="row">
                  <div class="col-lg-8">
                      <section class="panel">
                          <header class="panel-heading">
                             Edit Details Of <?php echo $edit['Doctor_name']; ?>
                             <span class="tools pull-right">
                                
                                 <a href="farming.php" style="color:#00F; font-weight:bold" >Back</a>
                             </span>
                          </header>
                          <div class="panel-body">
                              <form class="form-horizontal tasi-form" method="post" name="add" enctype="multipart/form-data">
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Doctor Name</label>
                                      <div class="col-sm-8">
                                          <input  type="text" name="Doctor_name" id="Doctor_name" placeholder=" Full Doctor Name " value="<?php echo $edit['Doctor_name']; ?>" class="form-control" required/>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Specialization</label>
                                      <div class="col-sm-8">
                                         <select name="Primary_specialization_id" class="form-control" required>
                                            <option value=""> - Select Specialization - </option>
                                            <?php
                                            $specialization_query=mysqli_query($connect,"SELECT * FROM `specialization`");
                                            while($specialization_query_row=mysqli_fetch_assoc($specialization_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $specialization_query_row["specialization_id"]; ?>' <?php if($specialization_query_row['specialization_id']==$edit['Primary_specialization_id']) { ?> selected <?php } ?>> <?php echo $specialization_query_row["specialization"]; ?> </option>
                                            <?php } ?>
                                          </select>
                                      </div>
                                  </div>
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Hospital</label>
                                      <div class="col-sm-8">
                                         <select name="Primary_Hospital_Id" class="form-control" required>
                                            <option value=""> - Select Hospital - </option>
                                            <?php
                                            $hospital_query=mysqli_query($connect,"SELECT * FROM `hospital`");
                                            while($hospital_query_row=mysqli_fetch_assoc($hospital_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $hospital_query_row["hospital_id"]; ?>' <?php if($hospital_query_row['hospital_id']==$edit['Primary_Hospital_Id']) { ?> selected <?php } ?>> <?php echo $hospital_query_row["hospital_name"]; ?> </option>
                                            <?php } ?></select>
                                      </div>
                                  </div>
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Qualification</label>
                                      <div class="col-sm-8">
                                         <select name="qualification" class="form-control" required>
                                            <option value=""> - Select Qualification - </option>
                                            <?php
                                            $qualification_query=mysqli_query($connect,"SELECT * FROM `qualification`");
                                            while($qualification_query_row=mysqli_fetch_assoc($qualification_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $qualification_query_row["Qualification_id"]; ?>' <?php if($qualification_query_row['Qualification_id']==$edit['qualification']) { ?> selected <?php } ?>> <?php echo $qualification_query_row["Qualification"]; ?> </option>
                                            <?php } ?></select>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Years Of Experience</label>
                                      <div class="col-sm-8">
                                        <select name="Years_of_Experience" id="Years_of_Experience" class="form-control" required>
                                            <option value=""> - Years of Experience - </option>
                                            <?php
                                                for($k=0; $k<12; $k++)
                                                {
                                                    ?>
                                                    <option value="<?php echo $k; ?>" <?php if($k==$edit['Years_of_Experience']) { ?> selected <?php } ?>><?php echo $k; ?></option>
                                                    <?php
                                                }
                                            ?>
                                            
                                            </select>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 control-label col-lg-4" for="inputSuccess">Address</label>
                                      <div class="col-sm-8">
                                          <input type="text" class="form-control m-bot15" name="Address_line1" id="Address_line1"  required placeholder="Door No / Flat No / Plot No " value="<?php echo $edit['Address_line1']; ?>" >
                                          <input type="text" class="form-control m-bot15" name="Address_line2" id="Address_line2"  required placeholder="Street Name / Line Name" value="<?php echo $edit['Address_line2']; ?>" >
                                          <input type="text" class="form-control m-bot15" name="Land_mark" id="Land_mark"  required placeholder="Land Mark" value="<?php echo $edit['Land_mark']; ?>" >
                                          <select name="City_id" id="City_id" class="form-control" required>
                                            
                                            <?php
                                            $city_query=mysqli_query($connect,"SELECT * FROM `city` WHERE `City_id`='$edit[City_id]'");
                                            while($city_query_row=mysqli_fetch_assoc($city_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $city_query_row["City_id"]; ?>' <?php if($edit['City_id']==$city_query_row['City_id']) { ?> selected <?php } ?>> <?php echo $city_query_row["City"]; ?> </option>
                                            <?php } ?>
                                          </select>
									  </div>
                                  </div>
                                  
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Date Of Birth</label>
                                      <div class="col-sm-8">
                                         <input type="date" name="DOB" id="DOB"  required value="<?php echo $edit['DOB']; ?>" class="form-control" />
                                      </div>
                                      
                                       
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Date Of Anniversary</label>
                                      <div class="col-sm-8">
                                        <input type="date" name="Date_Anniversary"  required id="Date_Anniversary"  value="<?php echo $edit['Date_Anniversary']; ?>" class="form-control"/>
                                      </div>
                                      
                                       
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Mobile</label>
                                      <div class="col-sm-8">
                                        <input type="number" name="Phone_number" id="Phone_number" placeholder="Phone Number"  value="<?php echo $edit['Phone_number']; ?>"  required  class="form-control"/>
                                      </div>
                                      
                                       
                                  </div>
                                  
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Email</label>
                                      <div class="col-sm-8">
                                        <input type="email" required name="emailid" id="emailid" placeholder=" Email Id"  value="<?php echo $edit['emailid']; ?>" class="form-control"/>
                                      </div>
                                      
                                       
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Password</label>
                                      <div class="col-sm-8">
                                        <input type="password" required class="form-control" name="password" id="password" placeholder=" Password"  value="<?php echo $edit['password']; ?>"/>
                                      </div>
                                      
                                       
                                  </div>
                                  
                                 <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Gender</label>
                                      <div class="col-sm-4">
                                          <input type="radio" name="Gender" value="Male" <?php if($edit['Gender']=="Male") { ?> checked <?php } ?>>&nbsp;&nbsp;Male
                                      </div>
                                      
                                        <div class="col-sm-4">
                                          <input type="radio" name="Gender" value="Female" <?php if($edit['Gender']=="Female") { ?> checked <?php } ?>>&nbsp;&nbsp;Female
                                      </div>  
                                  </div>
                                  
                                 
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Specialties</label>
                                      <div class="col-sm-8">
                                         <input type="text" name="Specialties" id="Specialties" placeholder="Specialties"  value="<?php echo $edit['Specialties']; ?>" class="form-control" required/>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Expertise</label>
                                      <div class="col-sm-8">
                                          <input type="text" name="expertise" id="expertise" placeholder="Expertise"  value="<?php echo $edit['expertise']; ?>" class="form-control" required/>
                                      </div>
                                  </div>
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Experince</label>
                                      <div class="col-sm-8">
                                          <input type="text" name="experince" id="experince" placeholder="Experince"  value="<?php echo $edit['experince']; ?>" class="form-control" required/>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Awards & Honours</label>
                                      <div class="col-sm-8">
                                          <input type="text" name="Awards_and_Honours" id="Awards_and_Honours" placeholder="Awards & Honours"  value="<?php echo $edit['Awards_and_Honours']; ?>" class="form-control" required/>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Research Work</label>
                                      <div class="col-sm-8">
                                          <input type="text" name="research" id="research" placeholder="Research Work"  value="<?php echo $edit['research']; ?>" class="form-control" required/>
                                      </div>
                                  </div>
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Doctor Image</label>
                                      <div class="col-sm-8">
                                          <input type="file" name="Doctor_image" id="Doctor_image" placeholder="Doctor Image"/><br>
<img src="../upload/<?php echo $edit['Doctor_image']; ?>" width="60" height="60">
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Languages Known</label>
                                       <?php 
										$lang_array=array();
										$lang = split(",",$edit['languages_known']);
										for($m=0; $m<count($lang); $m++)
										{
											$lang_array[]=$lang[$m];	
										}
										 ?>
                                      <div class="col-sm-3">
                                     
                                          <input type="checkbox" name="languages_known[]" id="languages_known[]" <?php if (in_array("English", $lang_array))
  {
  ?> checked <?php
  }
 ?> value="English">&nbsp;&nbsp;English
                                      </div>
                                      <div class="col-sm-3"><input type="checkbox" name="languages_known[]" id="languages_known[]" value="Telugu" <?php if (in_array("Telugu", $lang_array))
  {
  ?> checked <?php
  }
 ?>>&nbsp;&nbsp;Telugu  </div>
<div class="col-sm-3"><input type="checkbox" name="languages_known[]" id="languages_known[]" value="Hindi" <?php if (in_array("Hindi", $lang_array))
  {
  ?> checked <?php
  }
 ?>>&nbsp;&nbsp;Hindi  </div>
                                  </div>
                                  
                                  
                                  <input type="hidden" name="id" value="<?php echo $id; ?>">
                                  <div class="form-group">
                                      
                                      <div class="col-sm-4">
                                          &nbsp;
                                      </div>
                                      <div class="col-sm-4">
                                          <input type="submit" name="Submit" value="Update" class="btn btn-success">
                                      </div>
                                      <div class="col-sm-4">
                                          &nbsp;
                                      </div>
                                  </div>
                                  
                                  
                                 
                                 
                              </form>
                          </div>
                      </section>
                   </div>
              </div>
                                 
                                 
                         
                  
                  
                  <?php
			  }
			  else if(isset($_GET) && $_GET['action']=="delete")
			  {
				  	$deleted_query=mysqli_query($connect,"DELETE FROM `farming` WHERE `Farm_id`='$id'");
					if(isset($deleted_query))
					{
						header("location:farming.php?delete=yes");
					}
					else
					{
						header("location:farming.php?delete=no");
					}
			  }
			  else
			  {
			  ?>
              <?php
				if(isset($insert))
				{
					?>
				
					<div class="row">
						<div class="col-lg-4">
						&nbsp;
						</div>
						<div class="col-lg-4" style="text-align:center">                       
							<?php
							if($insert=="yes")
							{
								?>
									<div class="alert alert-success  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Successfully Inserted.
									 </div>
                                <?php
							}
							else
							{
								?>
									<div class="alert alert-danger  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Insertion Operation Failed.
                                    </div>
                                <?php
							}
							?>
								 
						</div>
						<div class="col-lg-4">
						&nbsp;
						</div>
					</div>
					<?php 
					} 
					?>
                     <?php
				if(isset($update))
				{
					?>
				
					<div class="row">
						<div class="col-lg-4">
						&nbsp;
						</div>
						<div class="col-lg-4" style="text-align:center">                       
							<?php
							if($update=="yes")
							{
								?>
									<div class="alert alert-success  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Successfully Updated.
									 </div>
                                <?php
							}
							else
							{
								?>
									<div class="alert alert-danger  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Update Operation Failured.
                                    </div>
                                <?php
							}
							?>
								 
						</div>
						<div class="col-lg-4">
						&nbsp;
						</div>
					</div>
					<?php 
					} 
					?>
                     <?php
				if(isset($delete))
				{
					?>
				
					<div class="row">
						<div class="col-lg-4">
						&nbsp;
						</div>
						<div class="col-lg-4" style="text-align:center">                       
							<?php
							if($delete=="yes")
							{
								?>
									<div class="alert alert-success  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Successfully  Deleted.
									 </div>
                                <?php
							}
							else
							{
								?>
									<div class="alert alert-danger  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Delete Operation Failed.
                                    </div>
                                <?php
							}
							?>
								 
						</div>
						<div class="col-lg-4">
						&nbsp;
						</div>
					</div>
					<?php 
					} 
					?>
              <div class="row">
                <div class="col-sm-12">
              <section class="panel">
              <header class="panel-heading">
                  List Of Farming
             <span class="tools pull-right">
                <a href="javascript:;" class="fa fa-chevron-down"></a>
                <a href="javascript:;" class="fa fa-times"></a>
             </span>
              </header>
              <div class="panel-body">
              <div class="adv-table">
              <table  class="display table table-bordered table-striped" id="dynamic-table">
              <thead>
              <tr>
                    <th width="6%">S.No</th>
                     <th width="20%">User Name</th>
                    <th width="22%">Farming Item</th>
                    <th width="13%">Farming Type</th>
                    <th width="20%">Quantity</th>
                    <th width="10%">Time Frame</th>
                    <th width="10%">Verified</th>
                    <th>Edit</th>
                    <th>Delete</th>
              </tr>
              </thead>
              <tbody>
              	<?php
				$sql_query=mysqli_query($connect,"SELECT * FROM `farming` ORDER BY `Farm_id` asc");
				$total=mysqli_num_rows($sql_query);
				if($total==0)
				{
					?>
                    <tr>
                    	<td  align="center">
                        	<font color="#FF0000"><strong>No Records</strong></font>
                        </td>
                    </tr>
                    <?php
				}
				else
				{
					$m=1;
					while($row=mysqli_fetch_array($sql_query))
					{	
						$user=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `user` WHERE `user_id`='$row[user_id]'"));
		$farmitem=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `farmitem` WHERE `FarmItem_id`='$row[FarmItem_id]'"));
		$farmtype=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `farmtype` WHERE `farmType_id`='$row[farmType_id]'"));		
        $unit=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `unittype` WHERE `unitType_id`='$row[unitType_id]'")); 	
						?>
                        <tr>
                            <td><?php echo $m; ?></td>
                                <td><?php echo $user['Fullname']; ?></td>
                            <td><?php echo $farmitem['farmitem']; ?></td>
                            <td><?php echo $farmtype['farmtype']; ?></td>
                            <td><?php echo $row['quantity'].' '.$unit['unittype']; ?></td>
                            <td><?php echo $row['timeframe']; ?></td>
                            <td><?php if($row['verified']==1) echo "Yes"; else echo "No"; ?></td>
                                            
                            <td><a href="farming.php?action=edit&id=<?php echo $row['Farm_id']; ?>"><button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button></a></td>
                            <td><a href="farming.php?action=delete&id=<?php echo $row['Farm_id']; ?>" onClick="return delete1();"><button class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i></button></a></td>
                        </tr>
                        <?php
						$m++;
					}
                	
				}
				?>
              </tbody>
              </table>
              </div>
              </div>
              </section>
              </div>
              </div>
              <?php 
			  }
			  ?>
              
              <!-- page end-->
          </section>
      </section>
      <!--main content end-->
      
      <!--footer start-->
      <footer class="site-footer" >
         <?php include "footer.php"; ?>
      </footer>
      <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->

    <script src="js/jquery.js"></script>
    <script src="js/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
    <script type="text/javascript" language="javascript" src="assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
    <script type="text/javascript" src="assets/data-tables/DT_bootstrap.js"></script>
    <script src="js/respond.min.js" ></script>

    <!--right slidebar-->
    <script src="js/slidebars.min.js"></script>

    <!--dynamic table initialization -->
    <script src="js/dynamic_table_init.js"></script>


    <!--common script for all pages-->
    <script src="js/common-scripts.js"></script>

  </body>

<!-- Mirrored from thevectorlab.net/flatlab/dynamic_table.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Nov 2014 04:52:22 GMT -->
</html>
