<?php ob_start();
session_start();
error_reporting(0);
include "../config.php";
include "secure.php";
include "pageing.php";
extract($_POST);
extract($_GET);
$date=date('Y-m-d H:i:s');
if(isset($_POST) && $_POST['Submit']=="Add")
{
	if(isset($_POST['languages_known'])) 
	{ 
		for($i=0; $i<count($languages_known); $i++)
		{
			$languages.=$_POST['languages_known'][$i].",";
		}
	
		$languages=substr($languages,0,-1);
	}
	$date_encrypt=md5($date);
	
	$file_name=$date_encrypt.$_FILES["Doctor_image"]["name"]; 
	
	$file_name=str_replace(" ","_",$file_name);
	
	$file_tmp_name=$_FILES["Doctor_image"]["tmp_name"]; 
	
	$path = "../upload/".$file_name;
	
	$moveResult = move_uploaded_file($file_tmp_name, $path);
	
	$number=rand(1000,9999);
	
	$space_doctor_name=str_replace(" ","",$Doctor_name);
	
	$Doctor_Unique_id=strtoupper(substr($space_doctor_name,0,3).$number);
	
	$city_rw=mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `city` WHERE `City_id`='$City_id'"));
	
	$address1=$Address_line1.",".$Address_line2.",".$Land_mark.",".$city_rw['City'];
	
	$insert=mysqli_query($connect,"INSERT INTO `doctor` (`Doctor_Unique_id`,`Doctor_name`, `Primary_specialization_id`, `Primary_Hospital_Id`, `Gender`, `DOB`, `Date_Anniversary`, `Address_line1`, `Address_line2`, `Land_mark`, `City_id`, `Phone_number`, `emailid`, `password`, `Years_of_Experience`, `qualification`, `Doctor_image`, `Specialties`, `expertise`, `experince`, `Awards_and_Honours`, `research`, `languages_known`,`preferred_address`,`address1`) VALUES ('$Doctor_Unique_id','$Doctor_name', '$Primary_specialization_id', '$Primary_Hospital_Id', '$Gender', '$DOB', '$Date_Anniversary', '$Address_line1', '$Address_line2', '$Land_mark', '$City_id', '$Phone_number', '$emailid', '$password', '$Years_of_Experience', '$qualification', '$file_name', '$Specialties', '$expertise', '$experince', '$Awards_and_Honours', '$research', '$languages','address1','$address1')");
	
	if($insert)
	{
		$specialization_query=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `specialization` WHERE `specialization_id`='$Primary_specialization_id'"));
		$hospital_query=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `hospital` WHERE `hospital_id`='$Primary_Hospital_Id'"));
		$qualification_query=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `qualification` WHERE `Qualification_id`='$Qualification'"));
		$city_query=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `city` WHERE `City_id`='$City_id'"));
		$to=$emailid;
		$subject="Registration Details";
		$message = '<html><body>';
		 
		$message .= '<table width="100%"; rules="all" style="border:1px solid #3A5896;" cellpadding="10">';
		 
		$message .= "<tr><td colspan=2 align='center'>Registration Details</td></tr>";
		$message .= "<tr><td>Doctor Name</td><td> $Doctor_name </td></tr>";
		$message .= "<tr><td>Hospital Name</td><td> $hospital_query[hospital_name] </td></tr>";
		$message .= "<tr><td>Password</td><td> $password </td></tr>";
		$message .= "<tr><td>Mobile Number</td><td> $Phone_number </td></tr>";
		 
		$message .= "</table>";
		 
		$message .= "</body></html>";
				  $from = 'no-reply@medserv.in';
		 
		 $headers = "From: " . strip_tags($from) . "\r\n";
		 $headers .= "MIME-Version: 1.0\r\n";
		 $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
		 mail($to,$subject,$message,$headers);
		 header("location:Doctor.php?insert=yes");
	}
	else
	{
		header("location:Doctor.php?insert=no");
	}
}
if(isset($_POST) && $_POST['Submit']=="Update")
{
	if(isset($_POST['languages_known'])) 
	{ 
		for($i=0; $i<count($languages_known); $i++)
		{
			$languages.=$_POST['languages_known'][$i].",";
		}
	
		$languages=substr($languages,0,-1);
	}
	$update_query=mysqli_query($connect,"UPDATE `doctor` SET `Doctor_name`='$Doctor_name', `Primary_specialization_id`='$Primary_specialization_id', `Primary_Hospital_Id`='$Primary_Hospital_Id', `Gender`='$Gender', `DOB`='$DOB', `Date_Anniversary`='$Date_Anniversary', `Address_line1`='$Address_line1', `Address_line2`='$Address_line2', `Land_mark`='$Land_mark', `City_id`='$City_id', `Phone_number`='$Phone_number', `emailid`='$emailid', `password`='$password', `Years_of_Experience`='$Years_of_Experience', `qualification`='$qualification', `Specialties`='$Specialties', `expertise`='$expertise', `experince`='$experince', `Awards_and_Honours`='$Awards_and_Honours', `research`='$research', `languages_known`='$languages' WHERE `Doctor_id`='$id'");
	if(isset($update_query))
	{
		if($_FILES["Doctor_image"]["name"]!='')
		{
			$date_encrypt=md5($date);
	
			$file_name=$date_encrypt.$_FILES["Doctor_image"]["name"]; 
			
			$file_name=str_replace(" ","_",$file_name);
			
			$file_tmp_name=$_FILES["Doctor_image"]["tmp_name"]; 
			
			$path = "../upload/".$file_name;
			
			$moveResult = move_uploaded_file($file_tmp_name, $path);
			$update_query=mysqli_query($connect,"UPDATE `doctor` SET `Doctor_image`='$file_name' WHERE `Doctor_id`='$id'");
		}
		header("location:Doctor.php?update=yes");
	}
	else
	{
		header("location:Doctor.php?update=no");
	}
}
?>
<!DOCTYPE html>
<html lang="en">
  

<head>
    <meta charset="utf-8">
    
    <link rel="shortcut icon" href="img/favicon.html">

    <title>Medserv.in</title>

    <!-- Bootstrap core CSS -->
      <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />

    <!--dynamic table-->
    <link href="assets/advanced-datatable/media/css/demo_page.css" rel="stylesheet" />
    <link href="assets/advanced-datatable/media/css/demo_table.css" rel="stylesheet" />
    <link rel="stylesheet" href="assets/data-tables/DT_bootstrap.css" />
      <!--right slidebar-->
      <link href="css/slidebars.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
    <script type="text/javascript">
function delete1()
{
  if(window.confirm("Confirm delete"))
  {
  return true;
   }
 else
   return false;
}
</script>
  </head>

  <body>

  <section id="container" class="">
      <!--header start-->
      <?php include "header.php"; ?>
      <!--header end-->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <?php include "sidemenu.php"; ?>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <!-- page start-->
              <?php
			  if(isset($_GET) && $_GET['action']=="add")
			  {
				  ?>
                  <div class="row">
                  <div class="col-lg-8">
                      <section class="panel">
                          <header class="panel-heading">
                             Add New Doctor
                             <span class="tools pull-right">
                                
                                 <a href="Doctor.php" style="color:#00F; font-weight:bold" >Back</a>
                             </span>
                          </header>
                          <div class="panel-body">
                              <form class="form-horizontal tasi-form" method="post" name="add" enctype="multipart/form-data">
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Doctor Name</label>
                                      <div class="col-sm-8">
                                          <input  type="text" name="Doctor_name" id="Doctor_name" placeholder=" Full Doctor Name " class="form-control" required/>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Specialization</label>
                                      <div class="col-sm-8">
                                         <select name="Primary_specialization_id" class="form-control" required>
                                            <option value=""> - Select Specialization - </option>
                                            <?php
                                            $specialization_query=mysqli_query($connect,"SELECT * FROM `specialization`");
                                            while($specialization_query_row=mysqli_fetch_assoc($specialization_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $specialization_query_row["specialization_id"]; ?>' > <?php echo $specialization_query_row["specialization"]; ?> </option>
                                            <?php } ?>
                                          </select>
                                      </div>
                                  </div>
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Hospital</label>
                                      <div class="col-sm-8">
                                         <select name="Primary_Hospital_Id" class="form-control" required>
                                            <option value=""> - Select Hospital - </option>
                                            <?php
                                            $hospital_query=mysqli_query($connect,"SELECT * FROM `hospital`");
                                            while($hospital_query_row=mysqli_fetch_assoc($hospital_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $hospital_query_row["hospital_id"]; ?>'> <?php echo $hospital_query_row["hospital_name"]; ?> </option>
                                            <?php } ?></select>
                                      </div>
                                  </div>
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Qualification</label>
                                      <div class="col-sm-8">
                                         <select name="qualification" class="form-control" required>
                                            <option value=""> - Select Qualification - </option>
                                            <?php
                                            $qualification_query=mysqli_query($connect,"SELECT * FROM `qualification`");
                                            while($qualification_query_row=mysqli_fetch_assoc($qualification_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $qualification_query_row["Qualification_id"]; ?>' > <?php echo $qualification_query_row["Qualification"]; ?> </option>
                                            <?php } ?></select>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Years Of Experience</label>
                                      <div class="col-sm-8">
                                        <select name="Years_of_Experience" id="Years_of_Experience" class="form-control" required>
                                            <option value=""> - Years of Experience - </option>
                                            <?php
                                                for($k=0; $k<12; $k++)
                                                {
                                                    ?>
                                                    <option value="<?php echo $k; ?>" ><?php echo $k; ?></option>
                                                    <?php
                                                }
                                            ?>
                                            
                                            </select>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 control-label col-lg-4" for="inputSuccess">Address</label>
                                      <div class="col-sm-8">
                                          <input type="text" class="form-control m-bot15" name="Address_line1" id="Address_line1"  required placeholder="Door No / Flat No / Plot No "  >
                                          <input type="text" class="form-control m-bot15" name="Address_line2" id="Address_line2"  required placeholder="Street Name / Line Name" >
                                          <input type="text" class="form-control m-bot15" name="Land_mark" id="Land_mark"  required placeholder="Land Mark"  >
                                          <select name="City_id" id="City_id" class="form-control" required>
                                            
                                            <?php
                                            $city_query=mysqli_query($connect,"SELECT * FROM `city`");
                                            while($city_query_row=mysqli_fetch_assoc($city_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $city_query_row["City_id"]; ?>' > <?php echo $city_query_row["City"]; ?> </option>
                                            <?php } ?>
                                          </select>
									  </div>
                                  </div>
                                  
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Date Of Birth</label>
                                      <div class="col-sm-8">
                                         <input type="date" name="DOB" id="DOB"  required  class="form-control" />
                                      </div>
                                      
                                       
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Date Of Anniversary</label>
                                      <div class="col-sm-8">
                                        <input type="date" name="Date_Anniversary"  required id="Date_Anniversary"   class="form-control"/>
                                      </div>
                                      
                                       
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Mobile</label>
                                      <div class="col-sm-8">
                                        <input type="number" name="Phone_number" id="Phone_number" placeholder="Phone Number"   required  class="form-control"/>
                                      </div>
                                      
                                       
                                  </div>
                                  
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Email</label>
                                      <div class="col-sm-8">
                                        <input type="email" required name="emailid" id="emailid" placeholder=" Email Id"  class="form-control"/>
                                      </div>
                                      
                                       
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Password</label>
                                      <div class="col-sm-8">
                                        <input type="password" required class="form-control" name="password" id="password" placeholder=" Password"  />
                                      </div>
                                      
                                       
                                  </div>
                                  
                                 <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Gender</label>
                                      <div class="col-sm-4">
                                          <input type="radio" name="Gender" value="Male" >&nbsp;&nbsp;Male
                                      </div>
                                      
                                        <div class="col-sm-4">
                                          <input type="radio" name="Gender" value="Female" >&nbsp;&nbsp;Female
                                      </div>  
                                  </div>
                                  
                                 
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Specialties</label>
                                      <div class="col-sm-8">
                                         <input type="text" name="Specialties" id="Specialties" placeholder="Specialties" class="form-control" required/>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Expertise</label>
                                      <div class="col-sm-8">
                                          <input type="text" name="expertise" id="expertise" placeholder="Expertise" class="form-control" required/>
                                      </div>
                                  </div>
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Experince</label>
                                      <div class="col-sm-8">
                                          <input type="text" name="experince" id="experince" placeholder="Experince" class="form-control" required/>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Awards & Honours</label>
                                      <div class="col-sm-8">
                                          <input type="text" name="Awards_and_Honours" id="Awards_and_Honours" placeholder="Awards & Honours"  class="form-control" required/>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Research Work</label>
                                      <div class="col-sm-8">
                                          <input type="text" name="research" id="research" placeholder="Research Work"   class="form-control" required/>
                                      </div>
                                  </div>
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Doctor Image</label>
                                      <div class="col-sm-8">
                                          <input type="file" name="Doctor_image" id="Doctor_image" placeholder="Doctor Image" required/>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Languages Known</label>
                                      <div class="col-sm-3">
                                     
                                          <input type="checkbox" name="languages_known[]" id="languages_known[]"  value="English">&nbsp;&nbsp;English
                                      </div>
                                      <div class="col-sm-3"><input type="checkbox" name="languages_known[]" id="languages_known[]" value="Telugu">&nbsp;&nbsp;Telugu  </div>
<div class="col-sm-3"><input type="checkbox" name="languages_known[]" id="languages_known[]" value="Hindi" >&nbsp;&nbsp;Hindi  </div>
                                  </div>
                                  
                                  
                               
                                  <div class="form-group">
                                      
                                      <div class="col-sm-4">
                                          &nbsp;
                                      </div>
                                      <div class="col-sm-4">
                                          <input type="submit" name="Submit" value="Add" class="btn btn-success">
                                      </div>
                                      <div class="col-sm-4">
                                          &nbsp;
                                      </div>
                                  </div>
                                  
                                  
                                 
                                 
                              </form>
                          </div>
                      </section>
                   </div>
              </div>
                  
                  <?php
			  }
			  else if(isset($_GET) && $_GET['action']=="edit")
			  {
				  $edit=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `doctor` WHERE `Doctor_id`='$id'"));
				  ?>
				  <div class="row">
                  <div class="col-lg-8">
                      <section class="panel">
                          <header class="panel-heading">
                             Edit Details Of <?php echo $edit['Doctor_name']; ?>
                             <span class="tools pull-right">
                                
                                 <a href="Doctor.php" style="color:#00F; font-weight:bold" >Back</a>
                             </span>
                          </header>
                          <div class="panel-body">
                              <form class="form-horizontal tasi-form" method="post" name="add" enctype="multipart/form-data">
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Doctor Name</label>
                                      <div class="col-sm-8">
                                          <input  type="text" name="Doctor_name" id="Doctor_name" placeholder=" Full Doctor Name " value="<?php echo $edit['Doctor_name']; ?>" class="form-control" required/>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Specialization</label>
                                      <div class="col-sm-8">
                                         <select name="Primary_specialization_id" class="form-control" required>
                                            <option value=""> - Select Specialization - </option>
                                            <?php
                                            $specialization_query=mysqli_query($connect,"SELECT * FROM `specialization`");
                                            while($specialization_query_row=mysqli_fetch_assoc($specialization_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $specialization_query_row["specialization_id"]; ?>' <?php if($specialization_query_row['specialization_id']==$edit['Primary_specialization_id']) { ?> selected <?php } ?>> <?php echo $specialization_query_row["specialization"]; ?> </option>
                                            <?php } ?>
                                          </select>
                                      </div>
                                  </div>
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Hospital</label>
                                      <div class="col-sm-8">
                                         <select name="Primary_Hospital_Id" class="form-control" required>
                                            <option value=""> - Select Hospital - </option>
                                            <?php
                                            $hospital_query=mysqli_query($connect,"SELECT * FROM `hospital`");
                                            while($hospital_query_row=mysqli_fetch_assoc($hospital_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $hospital_query_row["hospital_id"]; ?>' <?php if($hospital_query_row['hospital_id']==$edit['Primary_Hospital_Id']) { ?> selected <?php } ?>> <?php echo $hospital_query_row["hospital_name"]; ?> </option>
                                            <?php } ?></select>
                                      </div>
                                  </div>
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Qualification</label>
                                      <div class="col-sm-8">
                                         <select name="qualification" class="form-control" required>
                                            <option value=""> - Select Qualification - </option>
                                            <?php
                                            $qualification_query=mysqli_query($connect,"SELECT * FROM `qualification`");
                                            while($qualification_query_row=mysqli_fetch_assoc($qualification_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $qualification_query_row["Qualification_id"]; ?>' <?php if($qualification_query_row['Qualification_id']==$edit['qualification']) { ?> selected <?php } ?>> <?php echo $qualification_query_row["Qualification"]; ?> </option>
                                            <?php } ?></select>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Years Of Experience</label>
                                      <div class="col-sm-8">
                                        <select name="Years_of_Experience" id="Years_of_Experience" class="form-control" required>
                                            <option value=""> - Years of Experience - </option>
                                            <?php
                                                for($k=0; $k<12; $k++)
                                                {
                                                    ?>
                                                    <option value="<?php echo $k; ?>" <?php if($k==$edit['Years_of_Experience']) { ?> selected <?php } ?>><?php echo $k; ?></option>
                                                    <?php
                                                }
                                            ?>
                                            
                                            </select>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 control-label col-lg-4" for="inputSuccess">Address</label>
                                      <div class="col-sm-8">
                                          <input type="text" class="form-control m-bot15" name="Address_line1" id="Address_line1"  required placeholder="Door No / Flat No / Plot No " value="<?php echo $edit['Address_line1']; ?>" >
                                          <input type="text" class="form-control m-bot15" name="Address_line2" id="Address_line2"  required placeholder="Street Name / Line Name" value="<?php echo $edit['Address_line2']; ?>" >
                                          <input type="text" class="form-control m-bot15" name="Land_mark" id="Land_mark"  required placeholder="Land Mark" value="<?php echo $edit['Land_mark']; ?>" >
                                          <select name="City_id" id="City_id" class="form-control" required>
                                            
                                            <?php
                                            $city_query=mysqli_query($connect,"SELECT * FROM `city` WHERE `City_id`='$edit[City_id]'");
                                            while($city_query_row=mysqli_fetch_assoc($city_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $city_query_row["City_id"]; ?>' <?php if($edit['City_id']==$city_query_row['City_id']) { ?> selected <?php } ?>> <?php echo $city_query_row["City"]; ?> </option>
                                            <?php } ?>
                                          </select>
									  </div>
                                  </div>
                                  
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Date Of Birth</label>
                                      <div class="col-sm-8">
                                         <input type="date" name="DOB" id="DOB"  required value="<?php echo $edit['DOB']; ?>" class="form-control" />
                                      </div>
                                      
                                       
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Date Of Anniversary</label>
                                      <div class="col-sm-8">
                                        <input type="date" name="Date_Anniversary"  required id="Date_Anniversary"  value="<?php echo $edit['Date_Anniversary']; ?>" class="form-control"/>
                                      </div>
                                      
                                       
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Mobile</label>
                                      <div class="col-sm-8">
                                        <input type="number" name="Phone_number" id="Phone_number" placeholder="Phone Number"  value="<?php echo $edit['Phone_number']; ?>"  required  class="form-control"/>
                                      </div>
                                      
                                       
                                  </div>
                                  
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Email</label>
                                      <div class="col-sm-8">
                                        <input type="email" required name="emailid" id="emailid" placeholder=" Email Id"  value="<?php echo $edit['emailid']; ?>" class="form-control"/>
                                      </div>
                                      
                                       
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Password</label>
                                      <div class="col-sm-8">
                                        <input type="password" required class="form-control" name="password" id="password" placeholder=" Password"  value="<?php echo $edit['password']; ?>"/>
                                      </div>
                                      
                                       
                                  </div>
                                  
                                 <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Gender</label>
                                      <div class="col-sm-4">
                                          <input type="radio" name="Gender" value="Male" <?php if($edit['Gender']=="Male") { ?> checked <?php } ?>>&nbsp;&nbsp;Male
                                      </div>
                                      
                                        <div class="col-sm-4">
                                          <input type="radio" name="Gender" value="Female" <?php if($edit['Gender']=="Female") { ?> checked <?php } ?>>&nbsp;&nbsp;Female
                                      </div>  
                                  </div>
                                  
                                 
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Specialties</label>
                                      <div class="col-sm-8">
                                         <input type="text" name="Specialties" id="Specialties" placeholder="Specialties"  value="<?php echo $edit['Specialties']; ?>" class="form-control" required/>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Expertise</label>
                                      <div class="col-sm-8">
                                          <input type="text" name="expertise" id="expertise" placeholder="Expertise"  value="<?php echo $edit['expertise']; ?>" class="form-control" required/>
                                      </div>
                                  </div>
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Experince</label>
                                      <div class="col-sm-8">
                                          <input type="text" name="experince" id="experince" placeholder="Experince"  value="<?php echo $edit['experince']; ?>" class="form-control" required/>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Awards & Honours</label>
                                      <div class="col-sm-8">
                                          <input type="text" name="Awards_and_Honours" id="Awards_and_Honours" placeholder="Awards & Honours"  value="<?php echo $edit['Awards_and_Honours']; ?>" class="form-control" required/>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Research Work</label>
                                      <div class="col-sm-8">
                                          <input type="text" name="research" id="research" placeholder="Research Work"  value="<?php echo $edit['research']; ?>" class="form-control" required/>
                                      </div>
                                  </div>
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Doctor Image</label>
                                      <div class="col-sm-8">
                                          <input type="file" name="Doctor_image" id="Doctor_image" placeholder="Doctor Image"/><br>
<img src="../upload/<?php echo $edit['Doctor_image']; ?>" width="60" height="60">
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Languages Known</label>
                                       <?php 
										$lang_array=array();
										$lang = split(",",$edit['languages_known']);
										for($m=0; $m<count($lang); $m++)
										{
											$lang_array[]=$lang[$m];	
										}
										 ?>
                                      <div class="col-sm-3">
                                     
                                          <input type="checkbox" name="languages_known[]" id="languages_known[]" <?php if (in_array("English", $lang_array))
  {
  ?> checked <?php
  }
 ?> value="English">&nbsp;&nbsp;English
                                      </div>
                                      <div class="col-sm-3"><input type="checkbox" name="languages_known[]" id="languages_known[]" value="Telugu" <?php if (in_array("Telugu", $lang_array))
  {
  ?> checked <?php
  }
 ?>>&nbsp;&nbsp;Telugu  </div>
<div class="col-sm-3"><input type="checkbox" name="languages_known[]" id="languages_known[]" value="Hindi" <?php if (in_array("Hindi", $lang_array))
  {
  ?> checked <?php
  }
 ?>>&nbsp;&nbsp;Hindi  </div>
                                  </div>
                                  
                                  
                                  <input type="hidden" name="id" value="<?php echo $id; ?>">
                                  <div class="form-group">
                                      
                                      <div class="col-sm-4">
                                          &nbsp;
                                      </div>
                                      <div class="col-sm-4">
                                          <input type="submit" name="Submit" value="Update" class="btn btn-success">
                                      </div>
                                      <div class="col-sm-4">
                                          &nbsp;
                                      </div>
                                  </div>
                                  
                                  
                                 
                                 
                              </form>
                          </div>
                      </section>
                   </div>
              </div>
                  
                  
                  <?php
			  }
			  else if(isset($_GET) && $_GET['action']=="more")
			  {
				  $edit=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `doctor` WHERE `Doctor_id`='$id'"));
				  ?>
				  <div class="row">
                  <div class="col-lg-8">
                      <section class="panel">
                          <header class="panel-heading">
                             Edit Details Of <?php echo $edit['Doctor_name']; ?>
                             <span class="tools pull-right">
                                
                                 <a href="Doctor.php" style="color:#00F; font-weight:bold" >Back</a>
                             </span>
                          </header>
                          <div class="panel-body">
                              <form class="form-horizontal tasi-form" method="post" name="add" enctype="multipart/form-data">
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Id</label>
                                      <div class="col-sm-8">
                                          <input  type="text" name="Doctor_name" id="Doctor_name" placeholder=" Full Doctor Name " value="<?php echo $edit['Doctor_Unique_id']; ?>" class="form-control" required  readonly/>
                                      </div>
                                  </div>
                                    <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Doctor Name</label>
                                      <div class="col-sm-8">
                                          <input  type="text" name="Doctor_name" id="Doctor_name" placeholder=" Full Doctor Name " value="<?php echo $edit['Doctor_name']; ?>" class="form-control" required  readonly/>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Specialization</label>
                                      <div class="col-sm-8">
                                      
                                         <select name="Primary_specialization_id" class="form-control" required>
                                           
                                            <?php
                                            $specialization_query=mysqli_query($connect,"SELECT * FROM `specialization` WHERE `specialization_id`='$edit[Primary_specialization_id]'");
                                            while($specialization_query_row=mysqli_fetch_assoc($specialization_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $specialization_query_row["specialization_id"]; ?>'> <?php echo $specialization_query_row["specialization"]; ?> </option>
                                            <?php } ?>
                                          </select>
                                      </div>
                                  </div>
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Hospital</label>
                                      <div class="col-sm-8">
                                         <select name="Primary_Hospital_Id" class="form-control" required >
                                            <option value=""> - Select Hospital - </option>
                                            <?php
                                            $hospital_query=mysqli_query($connect,"SELECT * FROM `hospital` WHERE `hospital_id`='$edit[Primary_Hospital_Id]'");
                                            while($hospital_query_row=mysqli_fetch_assoc($hospital_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $hospital_query_row["hospital_id"]; ?>' <?php if($hospital_query_row['hospital_id']==$edit['Primary_Hospital_Id']) { ?> selected <?php } ?>> <?php echo $hospital_query_row["hospital_name"]; ?> </option>
                                            <?php } ?></select>
                                      </div>
                                  </div>
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Qualification</label>
                                      <div class="col-sm-8">
                                         <select name="qualification" class="form-control" required>
                                            <option value=""> - Select Qualification - </option>
                                            <?php
                                            $qualification_query=mysqli_query($connect,"SELECT * FROM `qualification` WHERE `Qualification_id`='$edit[qualification]'");
                                            while($qualification_query_row=mysqli_fetch_assoc($qualification_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $qualification_query_row["Qualification_id"]; ?>' <?php if($qualification_query_row['Qualification_id']==$edit['qualification']) { ?> selected <?php } ?>> <?php echo $qualification_query_row["Qualification"]; ?> </option>
                                            <?php } ?></select>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Years Of Experience</label>
                                      <div class="col-sm-8">
                                        <?php echo $edit['Years_of_Experience']; ?>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 control-label col-lg-4" for="inputSuccess">Address</label>
                                      <div class="col-sm-8">
                                          <input type="text" class="form-control m-bot15" name="Address_line1" id="Address_line1"  required placeholder="Door No / Flat No / Plot No " value="<?php echo $edit['Address_line1']; ?>" readonly >
                                          <input type="text" class="form-control m-bot15" name="Address_line2" id="Address_line2"  required placeholder="Street Name / Line Name" value="<?php echo $edit['Address_line2']; ?>" readonly>
                                          <input type="text" class="form-control m-bot15" name="Land_mark" id="Land_mark"  required placeholder="Land Mark" value="<?php echo $edit['Land_mark']; ?>"  readonly>
                                          <select name="City_id" id="City_id" class="form-control"  required>
                                            
                                            <?php
                                            $city_query=mysqli_query($connect,"SELECT * FROM `city` WHERE `City_id`='$edit[City_id]'");
                                            while($city_query_row=mysqli_fetch_assoc($city_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $city_query_row["City_id"]; ?>' <?php if($edit['City_id']==$city_query_row['City_id']) { ?> selected <?php } ?>> <?php echo $city_query_row["City"]; ?> </option>
                                            <?php } ?>
                                          </select>
									  </div>
                                  </div>
                                  
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Date Of Birth</label>
                                      <div class="col-sm-8">
                                         <input type="date" name="DOB" id="DOB"  required value="<?php echo $edit['DOB']; ?>" class="form-control"  readonly/>
                                      </div>
                                      
                                       
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Date Of Anniversary</label>
                                      <div class="col-sm-8">
                                        <input type="date" name="Date_Anniversary"  required id="Date_Anniversary"  value="<?php echo $edit['Date_Anniversary']; ?>" class="form-control"  readonly/>
                                      </div>
                                      
                                       
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Mobile</label>
                                      <div class="col-sm-8">
                                        <input type="number" name="Phone_number" id="Phone_number" placeholder="Phone Number"  value="<?php echo $edit['Phone_number']; ?>"  required  class="form-control"  readonly/>
                                      </div>
                                      
                                       
                                  </div>
                                  
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Email</label>
                                      <div class="col-sm-8">
                                        <input type="email" required name="emailid" id="emailid" placeholder=" Email Id"  value="<?php echo $edit['emailid']; ?>" class="form-control"  readonly/>
                                      </div>
                                      
                                       
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Password</label>
                                      <div class="col-sm-8">
                                        <input type="text" required class="form-control" name="password" id="password" placeholder=" Password"  value="<?php echo $edit['password']; ?>"  readonly/>
                                      </div>
                                      
                                       
                                  </div>
                                  
                                 <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Gender</label>
                                      <div class="col-sm-8">
                                          <?php echo $edit['Gender']; ?>
                                      </div>
                                      
                                      
                                  </div>
                                  
                                 
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Specialties</label>
                                      <div class="col-sm-8">
                                         <input type="text" name="Specialties" id="Specialties" placeholder="Specialties"  value="<?php echo $edit['Specialties']; ?>" class="form-control" required  readonly/>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Expertise</label>
                                      <div class="col-sm-8">
                                          <input type="text" name="expertise" id="expertise" placeholder="Expertise"  value="<?php echo $edit['expertise']; ?>" class="form-control" required  readonly/>
                                      </div>
                                  </div>
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Experince</label>
                                      <div class="col-sm-8">
                                          <input type="text" name="experince" id="experince" placeholder="Experince"  value="<?php echo $edit['experince']; ?>" class="form-control" required  readonly/>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Awards & Honours</label>
                                      <div class="col-sm-8">
                                          <input type="text" name="Awards_and_Honours" id="Awards_and_Honours" placeholder="Awards & Honours"  value="<?php echo $edit['Awards_and_Honours']; ?>" class="form-control" required  readonly/>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Research Work</label>
                                      <div class="col-sm-8">
                                          <input type="text" name="research" id="research" placeholder="Research Work"  value="<?php echo $edit['research']; ?>" class="form-control" required readonly/>
                                      </div>
                                  </div>
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Doctor Image</label>
                                      <div class="col-sm-8">
                                
<img src="../upload/<?php echo $edit['Doctor_image']; ?>" width="60" height="60">
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Languages Known</label>
                                      <div class="col-sm-8">
                                       <?php 
										echo $edit['languages_known']
										 ?>
                                         </div>
                                     
                                  </div>
                                  
                                
                                  
                                 
                                 
                              </form>
                          </div>
                      </section>
                   </div>
              </div>
                  
                  
                  <?php
			  }
			  else if(isset($_GET) && $_GET['action']=="delete")
			  {
				  	$deleted_query=mysqli_query($connect,"DELETE FROM `doctor` WHERE `Doctor_id`='$id'");
					if(isset($deleted_query))
					{
						header("location:Doctor.php?delete=yes");
					}
					else
					{
						header("location:Doctor.php?delete=no");
					}
			  }
			  else
			  {
			  ?>
              <?php
				if(isset($insert))
				{
					?>
				
					<div class="row">
						<div class="col-lg-4">
						&nbsp;
						</div>
						<div class="col-lg-4" style="text-align:center">                       
							<?php
							if($insert=="yes")
							{
								?>
									<div class="alert alert-success  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Successfully Inserted.
									 </div>
                                <?php
							}
							else
							{
								?>
									<div class="alert alert-danger  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Insertion Operation Failed.
                                    </div>
                                <?php
							}
							?>
								 
						</div>
						<div class="col-lg-4">
						&nbsp;
						</div>
					</div>
					<?php 
					} 
					?>
                     <?php
				if(isset($update))
				{
					?>
				
					<div class="row">
						<div class="col-lg-4">
						&nbsp;
						</div>
						<div class="col-lg-4" style="text-align:center">                       
							<?php
							if($update=="yes")
							{
								?>
									<div class="alert alert-success  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Successfully Updated.
									 </div>
                                <?php
							}
							else
							{
								?>
									<div class="alert alert-danger  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Update Operation Failured.
                                    </div>
                                <?php
							}
							?>
								 
						</div>
						<div class="col-lg-4">
						&nbsp;
						</div>
					</div>
					<?php 
					} 
					?>
                     <?php
				if(isset($delete))
				{
					?>
				
					<div class="row">
						<div class="col-lg-4">
						&nbsp;
						</div>
						<div class="col-lg-4" style="text-align:center">                       
							<?php
							if($delete=="yes")
							{
								?>
									<div class="alert alert-success  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Successfully  Deleted.
									 </div>
                                <?php
							}
							else
							{
								?>
									<div class="alert alert-danger  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Delete Operation Failed.
                                    </div>
                                <?php
							}
							?>
								 
						</div>
						<div class="col-lg-4">
						&nbsp;
						</div>
					</div>
					<?php 
					} 
					?>
              <div class="row">
                <div class="col-sm-12">
              <section class="panel">
              <header class="panel-heading">
                  List Of Doctors
             <span class="tools pull-right">
                <a href="javascript:;" class="fa fa-chevron-down"></a>
                <a href="javascript:;" class="fa fa-times"></a>
             </span>
              </header>
              <div class="panel-body">
              <div class="adv-table">
              <table  class="display table table-bordered table-striped" id="dynamic-table">
              <thead>
              <tr>
                    <th width="6%">S.No</th>
                     <th width="20%">Doctor ID</th>
                    <th width="22%">Doctor Name</th>
                    <th width="13%">Specialization</th>
                    <th width="20%">Hospital</th>
                    <th width="10%">Qualification</th>
                    <th width="10%">Experience</th>
                    <th width="10%">Specialities</th>
                   
                    <th>More</th>
                    <th>Edit</th>
                    <th>Delete</th>
              </tr>
              </thead>
              <tbody>
              	<?php
				$sql_query=mysqli_query($connect,"SELECT * FROM `doctor` ORDER BY `Doctor_id` asc");
				$total=mysqli_num_rows($sql_query);
				if($total==0)
				{
					?>
                    <tr>
                    	<td  align="center">
                        	<font color="#FF0000"><strong>No Records</strong></font>
                        </td>
                    </tr>
                    <?php
				}
				else
				{
					$m=1;
					while($row=mysqli_fetch_array($sql_query))
					{	
						$specialization=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `specialization` WHERE `specialization_id`='$row[Primary_specialization_id]'"));
		$hospital=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `hospital` WHERE `hospital_id`='$row[Primary_Hospital_Id]'"));
		$qualification=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `qualification` WHERE `Qualification_id`='$row[qualification]'"));			
						?>
                        <tr>
                            <td><?php echo $m; ?></td>
                                <td><?php echo $row['Doctor_Unique_id']; ?></td>
                            <td><?php echo $row['Doctor_name']; ?></td>
                            <td><?php echo $specialization['specialization']; ?></td>
                            <td><?php echo $hospital['hospital_name']; ?></td>
                            <td><?php echo $qualification['Qualification']; ?></td>
                            <td><?php echo $row['Years_of_Experience']; ?></td>
                            <td><?php echo $row['Specialties']; ?></td>
                         
                            <td><a href="Doctor.php?action=more&id=<?php echo $row['Doctor_id']; ?>"><button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button></a></td>
                            <td><a href="Doctor.php?action=edit&id=<?php echo $row['Doctor_id']; ?>"><button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button></a></td>
                            <td><a href="Doctor.php?action=delete&id=<?php echo $row['Doctor_id']; ?>" onClick="return delete1();"><button class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i></button></a></td>
                        </tr>
                        <?php
						$m++;
					}
                	
				}
				?>
              </tbody>
              </table>
              </div>
              </div>
              </section>
              </div>
              </div>
              <?php 
			  }
			  ?>
              
              <!-- page end-->
          </section>
      </section>
      <!--main content end-->
      
      <!--footer start-->
      <footer class="site-footer" >
         <?php include "footer.php"; ?>
      </footer>
      <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->

    <script src="js/jquery.js"></script>
    <script src="js/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
    <script type="text/javascript" language="javascript" src="assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
    <script type="text/javascript" src="assets/data-tables/DT_bootstrap.js"></script>
    <script src="js/respond.min.js" ></script>

    <!--right slidebar-->
    <script src="js/slidebars.min.js"></script>

    <!--dynamic table initialization -->
    <script src="js/dynamic_table_init.js"></script>


    <!--common script for all pages-->
    <script src="js/common-scripts.js"></script>

  </body>

<!-- Mirrored from thevectorlab.net/flatlab/dynamic_table.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Nov 2014 04:52:22 GMT -->
</html>
