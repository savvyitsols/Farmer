<?php
include "../config.php";
extract($_POST);
extract($_GET);
$doctor=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `doctor` WHERE `Doctor_id`='$Doctor_id'"));
$sql=mysqli_query($connect,"SELECT * FROM `specialization` WHERE `specialization_id`!='$doctor[Primary_specialization_id]'");

?>
<select name="Specialization_id" id="Specialization_id" class="form-control" required>
<option value=""> - Select Specialization - </option>
<?php

while($sql_row=mysqli_fetch_assoc($sql))
{
?>

<option value='<?php echo $sql_row["specialization_id"]; ?>'> <?php echo $sql_row["specialization"]; ?> </option>
<?php } ?>
</select>