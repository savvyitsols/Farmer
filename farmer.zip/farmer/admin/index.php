<?php ob_start();
session_start();
error_reporting(0);
include "../config.php";
extract($_POST);
extract($_GET);
session_start();
unset($_SESSION['Admin_id']);
if(isset($_POST) && $_POST['Submit']=="Sign In")
{
	$check_query=mysqli_query($connect,"SELECT * FROM `admin` WHERE `Admin_User_Name`='$Admin_User_Name' AND `Admin_Password`='$password'");
	
	$check_query_total=mysqli_num_rows($check_query);
	if($check_query_total==0)
	{
		header("location:index.php?msg1=no");
		
	}
	else
	{
		$fetch_query=mysqli_fetch_array($check_query);
		
		$_SESSION['Admin_id']=$fetch_query['Admin_id'];
		header("location:admin_home.php");
		
	}
	
}
if(isset($_POST) && $_POST['Submit']=="Submit")
{
	$check_query=mysqli_query($connect,"SELECT * FROM `admin` WHERE `Email_Id`='$email'");
	$check_query_total=mysqli_num_rows($check_query);
	if($check_query_total==0)
	{
		header("location:index.php?msg3=no");
		
	}
	else
	{
		$fetch_query=mysqli_fetch_array($check_query);
		
		$to=$email;
		$subject="Forgot Password Details";
		$message = '<html><body>';
		 
		$message .= '<table width="100%"; rules="all" style="border:1px solid #3A5896;" cellpadding="10">';
		 
		$message .= "<tr><td colspan=2 align='center'>Forgot Password Details</td></tr>";
		$message .= "<tr><td>Password</td><td> $fetch_query[Admin_Password] </td></tr>";
		
		$message .= "</table>";
		 
		$message .= "</body></html>";
				  $from = 'savvyitsols@gmail.com';
		 
		  $headers = "From: " . strip_tags($from) . "\r\n";
		   $headers .= "MIME-Version: 1.0\r\n";
		  $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
		 mail($to,$subject,$message,$headers);
		header("location:index.php?msg2=yes");
	}
	
	
}
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from thevectorlab.net/flatlab/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Nov 2014 04:50:05 GMT -->
<head>
    <meta charset="utf-8">
    
    <link rel="shortcut icon" href="img/favicon.html">

    <title>Farmer</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>
<body class="login-body">
	<div class="container">
    	<header class="header white-bg">
         	<div class="sidebar-toggle-box">
            	<div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
            </div>
            <!--logo start-->
            <a href="index.php" class="logo">Farmer<span>ind.com</span></a>
            <!--logo end-->
         </header>
        <?php
			if(isset($msg1))
			{
				?>
   				<div class="row">
   					<div class="col-lg-12">&nbsp;</div>
   				</div>
                <div class="row">
   					<div class="col-lg-12">&nbsp;</div>
   				</div>
                <div class="row">
   					<div class="col-lg-12">&nbsp;</div>
   				</div>
                <div class="row">
   					<div class="col-lg-12">&nbsp;</div>
   				</div>
   				<div class="row">
                	<div class="col-lg-4">
                    &nbsp;
                    </div>
       				<div class="col-lg-4" style="text-align:center">                       
             			
                				<div class="alert alert-block alert-danger fade in">
                                 	<button data-dismiss="alert" class="close close-sm" type="button">
                                      <i class="fa fa-times"></i>
                                  	</button>
                                  	<strong>Oh snap!</strong> Invalid Login Details.
                                 </div>
                             
       				</div>
                    <div class="col-lg-4">
                    &nbsp;
                    </div>
				</div>
				<?php 
				} 
				?>
                <?php
			if(isset($msg2))
			{
				?>
   				<div class="row">
   					<div class="col-lg-12">&nbsp;</div>
   				</div>
                <div class="row">
   					<div class="col-lg-12">&nbsp;</div>
   				</div>
                <div class="row">
   					<div class="col-lg-12">&nbsp;</div>
   				</div>
                <div class="row">
   					<div class="col-lg-12">&nbsp;</div>
   				</div>
   				<div class="row">
                	<div class="col-lg-4">
                    &nbsp;
                    </div>
       				<div class="col-lg-4" style="text-align:center">                       
             			
                				<div class="alert alert-success  fade in">
                                 	<button data-dismiss="alert" class="close close-sm" type="button">
                                      <i class="fa fa-times"></i>
                                  	</button>
                                  	Password Sent to your mail Id.Check Your Mail.
                                 </div>
                             
       				</div>
                    <div class="col-lg-4">
                    &nbsp;
                    </div>
				</div>
				<?php 
				} 
				?>
                <?php
			if(isset($msg3))
			{
				?>
   				<div class="row">
   					<div class="col-lg-12">&nbsp;</div>
   				</div>
                <div class="row">
   					<div class="col-lg-12">&nbsp;</div>
   				</div>
                <div class="row">
   					<div class="col-lg-12">&nbsp;</div>
   				</div>
                <div class="row">
   					<div class="col-lg-12">&nbsp;</div>
   				</div>
   				<div class="row">
                	<div class="col-lg-4">
                    &nbsp;
                    </div>
       				<div class="col-lg-4" style="text-align:center">                       
             			
                				<div class="alert alert-block alert-danger fade in">
                                 	<button data-dismiss="alert" class="close close-sm" type="button">
                                      <i class="fa fa-times"></i>
                                  	</button>
                                  	You Entered Wrong Mail ID.Please tru again.
                                 </div>
                             
       				</div>
                    <div class="col-lg-4">
                    &nbsp;
                    </div>
				</div>
				<?php 
				} 
				?>
				<div class="row">
					<div class="col-lg-12">
      					<form class="form-signin" action="" method="post"  name="login">
         
        
                            <h2 class="form-signin-heading">sign in now</h2>
                            <div class="login-wrap">
                                <input type="text" required name="Admin_User_Name" id="Admin_User_Name" class="form-control" placeholder="User ID" autofocus>
                                <input type="password" required name="password" id="password" class="form-control" placeholder="Password">
                                <label class="checkbox">
                                   
                                    <span class="pull-right">
                                        <a data-toggle="modal" href="#myModal"> Forgot Password?</a>
                    
                                    </span>
                                </label>
                                <button class="btn btn-lg btn-login btn-block" type="submit" name="Submit" value="Sign In">Sign in</button>
                                
                                
                                
                    
                            </div>
					</form>
          <!-- Modal -->
          <form name="forgot" method="post" action="" class="form-signin">
          <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal" class="modal fade">
              <div class="modal-dialog">
                  <div class="modal-content">
                      <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                          <h4 class="modal-title">Forgot Password ?</h4>
                      </div>
                      <div class="modal-body">
                          <p>Enter your e-mail address below to reset your password.</p>
                          <input type="email" name="email" id="email" placeholder="Email" autocomplete="off" class="form-control placeholder-no-fix" required>

                      </div>
                      <div class="modal-footer">
                          <button data-dismiss="modal" class="btn btn-default" type="button">Cancel</button>
                          <button class="btn btn-success" type="submit" name="Submit" value="Submit">Submit</button>
                      </div>
                  </div>
              </div>
          </div>
          <!-- modal -->
</form>
     
</div>
    </div>
</div>
</body>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>


  </body>

<!-- Mirrored from thevectorlab.net/flatlab/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Nov 2014 04:50:05 GMT -->
</html>
