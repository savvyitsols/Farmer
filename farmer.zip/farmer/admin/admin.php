<?php ob_start();
session_start();
error_reporting(0);
include "../config.php";
include "secure.php";
include "pageing.php";
extract($_POST);
extract($_GET);
$date=date('Y-m-d H:i:s');
if(isset($_POST) && $_POST['Submit']=="Add")
{
	$date_encrypt=md5($date);
	
	$city_rw=mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `city` WHERE `City_id`='$City_id'"));
	
	$address1=$Address_line1.",".$Address_line2.",".$Land_mark.",".$city_rw['City'];
	
	$insert=mysqli_query($connect,"INSERT INTO `admin` (`Admin_User_Name`, `Admin_Password`,`Phone_no`, `Email_Id`, `line1`, `line2`, `Land_mark`, `City_id`) VALUES ('$Admin_User_Name','$password','$Phone_no', '$Email_Id', '$Address_line1', '$Address_line2', '$Land_mark', '$City_id')");
	
	if($insert)
	{
		$city_query=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `city` WHERE `City_id`='$City_id'"));
		$to=$emailid;
		$subject="Registration Details";
		$message = '<html><body>';
		 
		$message .= '<table width="100%"; rules="all" style="border:1px solid #3A5896;" cellpadding="10">';
		 
		$message .= "<tr><td colspan=2 align='center'>Registration Details</td></tr>";
		$message .= "<tr><td>Admin Name</td><td> $Admin_User_Name </td></tr>";
		$message .= "<tr><td>Password</td><td> $password </td></tr>";
		$message .= "<tr><td>Mobile Number</td><td> $Phone_number </td></tr>";
		 
		$message .= "</table>";
		 
		$message .= "</body></html>";
				  $from = 'savvyitsols@gmail.com';
		 
		 $headers = "From: " . strip_tags($from) . "\r\n";
		 $headers .= "MIME-Version: 1.0\r\n";
		 $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
		 mail($to,$subject,$message,$headers);
		 header("location:admin.php?insert=yes");
	}
	else
	{
		header("location:admin.php?insert=no");
	}
}
if(isset($_POST) && $_POST['Submit']=="Update")
{
	$update_query=mysqli_query($connect,"UPDATE `admin` SET `Admin_User_Name`='$Admin_User_Name', `Admin_Password`='$password', `Phone_no`='$Phone_no', `Email_Id`='$Email_Id', `line1`='$line1', `line2`='$line2', `Land_mark`='$Land_mark', `City_id`='$City_id' WHERE `Admin_id`='$id'");
	if(isset($update_query))
	{
		header("location:admin.php?update=yes");
	}
	else
	{
		header("location:admin.php?update=no");
	}
}
?>
<!DOCTYPE html>
<html lang="en">
  

<head>
    <meta charset="utf-8">
    
    <link rel="shortcut icon" href="img/favicon.html">

    <title>Farmer</title>

    <!-- Bootstrap core CSS -->
      <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />

    <!--dynamic table-->
    <link href="assets/advanced-datatable/media/css/demo_page.css" rel="stylesheet" />
    <link href="assets/advanced-datatable/media/css/demo_table.css" rel="stylesheet" />
    <link rel="stylesheet" href="assets/data-tables/DT_bootstrap.css" />
      <!--right slidebar-->
      <link href="css/slidebars.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
    <script type="text/javascript">
function delete1()
{
  if(window.confirm("Confirm delete"))
  {
  return true;
   }
 else
   return false;
}
</script>
  </head>

  <body>

  <section id="container" class="">
      <!--header start-->
      <?php include "header.php"; ?>
      <!--header end-->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <?php include "sidemenu.php"; ?>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <!-- page start-->
              <?php
			  if(isset($_GET) && $_GET['action']=="add")
			  {
				  ?>
                  <div class="row">
                  <div class="col-lg-8">
                      <section class="panel">
                          <header class="panel-heading">
                             Add New Admin
                             <span class="tools pull-right">
                                
                                 <a href="admin.php" style="color:#00F; font-weight:bold" >Back</a>
                             </span>
                          </header>
                          <div class="panel-body">
                              <form class="form-horizontal tasi-form" method="post" name="add" enctype="multipart/form-data">
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Admin User Name</label>
                                      <div class="col-sm-8">
                                          <input  type="text" name="Admin_User_Name" id="Admin_User_Name" placeholder=" Admin User Name " class="form-control" required/>
                                      </div>
                                  </div>
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 control-label col-lg-4" for="inputSuccess">Address</label>
                                      <div class="col-sm-8">
                                          <input type="text" class="form-control m-bot15" name="Address_line1" id="Address_line1"  required placeholder="Door No / Flat No / Plot No "  >
                                          <input type="text" class="form-control m-bot15" name="Address_line2" id="Address_line2"  required placeholder="Street Name / Line Name" >
                                          <input type="text" class="form-control m-bot15" name="Land_mark" id="Land_mark"  required placeholder="Land Mark"  >
                                          <select name="City_id" id="City_id" class="form-control" required>
                                            
                                            <?php
                                            $city_query=mysqli_query($connect,"SELECT * FROM `city`");
                                            while($city_query_row=mysqli_fetch_assoc($city_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $city_query_row["City_id"]; ?>' > <?php echo $city_query_row["City"]; ?> </option>
                                            <?php } ?>
                                          </select>
									  </div>
                                  </div>
                                  
                                  
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Mobile</label>
                                      <div class="col-sm-8">
                                        <input type="number" name="Phone_no" id="Phone_no" placeholder="Phone Number"   required  class="form-control"/>
                                      </div>
                                      
                                       
                                  </div>
                                  
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Email</label>
                                      <div class="col-sm-8">
                                        <input type="email" required name="Email_Id" id="Email_Id" placeholder=" Email Id"  class="form-control"/>
                                      </div>
                                      
                                       
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Password</label>
                                      <div class="col-sm-8">
                                        <input type="password" required class="form-control" name="password" id="password" placeholder=" Password"  />
                                      </div>
                                      
                                       
                                  </div>
                                  
                                  
                               
                                  <div class="form-group">
                                      
                                      <div class="col-sm-4">
                                          &nbsp;
                                      </div>
                                      <div class="col-sm-4">
                                          <input type="submit" name="Submit" value="Add" class="btn btn-success">
                                      </div>
                                      <div class="col-sm-4">
                                          &nbsp;
                                      </div>
                                  </div>
                                  
                                  
                                 
                                 
                              </form>
                          </div>
                      </section>
                   </div>
              </div>
                  
                  <?php
			  }
			  else if(isset($_GET) && $_GET['action']=="edit")
			  {
				  $edit=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `admin` WHERE `Admin_id`='$id'"));
				  ?>
				  <div class="row">
                  <div class="col-lg-8">
                      <section class="panel">
                          <header class="panel-heading">
                             Edit Details Of <?php echo $edit['Admin_User_Name']; ?>
                             <span class="tools pull-right">
                                
                                 <a href="admin.php" style="color:#00F; font-weight:bold" >Back</a>
                             </span>
                          </header>
                          <div class="panel-body">
                              <form class="form-horizontal tasi-form" method="post" name="add" enctype="multipart/form-data">
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Admin user Name</label>
                                      <div class="col-sm-8">
                                          <input  type="text" name="Admin_User_Name" id="Admin_User_Name" placeholder=" Admin User Name " value="<?php echo $edit['Admin_User_Name']; ?>" class="form-control" required/>
                                      </div>
                                  </div>
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 control-label col-lg-4" for="inputSuccess">Address</label>
                                      <div class="col-sm-8">
                                          <input type="text" class="form-control m-bot15" name="line1" id="line1"  required placeholder="Door No / Flat No / Plot No " value="<?php echo $edit['line1']; ?>" >
                                          <input type="text" class="form-control m-bot15" name="line2" id="line2"  required placeholder="Street Name / Line Name" value="<?php echo $edit['line2']; ?>" >
                                          <input type="text" class="form-control m-bot15" name="Land_mark" id="Land_mark"  required placeholder="Land Mark" value="<?php echo $edit['Land_mark']; ?>" >
                                          <select name="City_id" id="City_id" class="form-control" required>
                                            
                                            <?php
                                            $city_query=mysqli_query($connect,"SELECT * FROM `city` WHERE `City_id`='$edit[City_id]'");
                                            while($city_query_row=mysqli_fetch_assoc($city_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $city_query_row["City_id"]; ?>' <?php if($edit['City_id']==$city_query_row['City_id']) { ?> selected <?php } ?>> <?php echo $city_query_row["City"]; ?> </option>
                                            <?php } ?>
                                          </select>
									  </div>
                                  </div>
                                  
                                  
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Mobile</label>
                                      <div class="col-sm-8">
                                        <input type="number" name=" Phone_no" id="  Phone_no" placeholder="Phone Number"  value="<?php echo $edit['Phone_no']; ?>"  required  class="form-control"/>
                                      </div>
                                      
                                       
                                  </div>
                                  
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Email</label>
                                      <div class="col-sm-8">
                                        <input type="email" required name="Email_Id" id="Email_Id" placeholder=" Email Id"  value="<?php echo $edit['Email_Id']; ?>" class="form-control"/>
                                      </div>
                                      
                                       
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Password</label>
                                      <div class="col-sm-8">
                                        <input type="password" required class="form-control" name="password" id="password" placeholder=" Password"  value="<?php echo $edit['Admin_Password']; ?>"/>
                                      </div>
                                      
                                       
                                  </div>
                                  <input type="hidden" name="id" value="<?php echo $id; ?>">
                                  <div class="form-group">
                                      
                                      <div class="col-sm-4">
                                          &nbsp;
                                      </div>
                                      <div class="col-sm-4">
                                          <input type="submit" name="Submit" value="Update" class="btn btn-success">
                                      </div>
                                      <div class="col-sm-4">
                                          &nbsp;
                                      </div>
                                  </div>
                                  
                                  
                                 
                                 
                              </form>
                          </div>
                      </section>
                   </div>
              </div>
        <?php
			  }
			  else if(isset($_GET) && $_GET['action']=="delete")
			  {
				  	$deleted_query=mysqli_query($connect,"DELETE FROM `doctor` WHERE `Doctor_id`='$id'");
					if(isset($deleted_query))
					{
						header("location:admin.php?delete=yes");
					}
					else
					{
						header("location:admin.php?delete=no");
					}
			  }
			  else
			  {
			  ?>
              <?php
				if(isset($insert))
				{
					?>
				
					<div class="row">
						<div class="col-lg-4">
						&nbsp;
						</div>
						<div class="col-lg-4" style="text-align:center">                       
							<?php
							if($insert=="yes")
							{
								?>
									<div class="alert alert-success  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Successfully Inserted.
									 </div>
                                <?php
							}
							else
							{
								?>
									<div class="alert alert-danger  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Insertion Operation Failed.
                                    </div>
                                <?php
							}
							?>
								 
						</div>
						<div class="col-lg-4">
						&nbsp;
						</div>
					</div>
					<?php 
					} 
					?>
                     <?php
				if(isset($update))
				{
					?>
				
					<div class="row">
						<div class="col-lg-4">
						&nbsp;
						</div>
						<div class="col-lg-4" style="text-align:center">                       
							<?php
							if($update=="yes")
							{
								?>
									<div class="alert alert-success  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Successfully Updated.
									 </div>
                                <?php
							}
							else
							{
								?>
									<div class="alert alert-danger  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Update Operation Failured.
                                    </div>
                                <?php
							}
							?>
								 
						</div>
						<div class="col-lg-4">
						&nbsp;
						</div>
					</div>
					<?php 
					} 
					?>
                     <?php
				if(isset($delete))
				{
					?>
				
					<div class="row">
						<div class="col-lg-4">
						&nbsp;
						</div>
						<div class="col-lg-4" style="text-align:center">                       
							<?php
							if($delete=="yes")
							{
								?>
									<div class="alert alert-success  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Successfully  Deleted.
									 </div>
                                <?php
							}
							else
							{
								?>
									<div class="alert alert-danger  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Delete Operation Failed.
                                    </div>
                                <?php
							}
							?>
								 
						</div>
						<div class="col-lg-4">
						&nbsp;
						</div>
					</div>
					<?php 
					} 
					?>
              <div class="row">
                <div class="col-sm-12">
              <section class="panel">
              <header class="panel-heading">
                  List Of Admins
             <span class="tools pull-right">
                <a href="javascript:;" class="fa fa-chevron-down"></a>
                <a href="javascript:;" class="fa fa-times"></a>
             </span>
              </header>
              <div class="panel-body">
              <div class="adv-table">
              <table  class="display table table-bordered table-striped" id="dynamic-table">
              <thead>
              <tr>
                    <th width="6%">S.No</th>
                     <th width="20%">Admin User Name</th>
                    <th width="22%">Phone Number</th>
                    <th width="13%">Email Id</th>
                    <th width="20%">Address</th>
                    <th>Edit</th>
                    <th>Delete</th>
              </tr>
              </thead>
              <tbody>
              	<?php
				$sql_query=mysqli_query($connect,"SELECT * FROM `admin` ORDER BY `Admin_id` asc");
				$total=mysqli_num_rows($sql_query);
				if($total==0)
				{
					?>
                    <tr>
                    	<td  align="center">
                        	<font color="#FF0000"><strong>No Records</strong></font>
                        </td>
                    </tr>
                    <?php
				}
				else
				{
					$m=1;
					while($row=mysqli_fetch_array($sql_query))
					{	
							$City=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `city` WHERE `City_id`='$row[City_id]'"));	
              $State=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `state` WHERE `State_id`='$City[State_Id]'")); 
               $country=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `country` WHERE `Country_id`='$State[Country_Id]'"));   	
						?>
                        <tr>
                            <td><?php echo $m; ?></td>
                                <td><?php echo $row['Admin_User_Name']; ?></td>
                            <td><?php echo $row['Phone_no']; ?></td>
                            <td><?php echo $row['Email_Id']; ?></td>
                            <td><?php echo $row['line1'].',</br>'.$row['line2'].',</br>'.$row['Land_mark'].',</br>'.$City['City'].',</br>'.$State['State'].',</br>'.$country['Country']; ?></td>
                            
                            <td><a href="admin.php?action=edit&id=<?php echo $row['Admin_id']; ?>"><button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button></a></td>
                            <td><a href="admin.php?action=delete&id=<?php echo $row['Admin_id']; ?>" onClick="return delete1();"><button class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i></button></a></td>
                        </tr>
                        <?php
						$m++;
					}
                	
				}
				?>
              </tbody>
              </table>
              </div>
              </div>
              </section>
              </div>
              </div>
              <?php 
			  }
			  ?>
              
              <!-- page end-->
          </section>
      </section>
      <!--main content end-->
      
      <!--footer start-->
      <footer class="site-footer" >
         <?php include "footer.php"; ?>
      </footer>
      <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->

    <script src="js/jquery.js"></script>
    <script src="js/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
    <script type="text/javascript" language="javascript" src="assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
    <script type="text/javascript" src="assets/data-tables/DT_bootstrap.js"></script>
    <script src="js/respond.min.js" ></script>

    <!--right slidebar-->
    <script src="js/slidebars.min.js"></script>

    <!--dynamic table initialization -->
    <script src="js/dynamic_table_init.js"></script>


    <!--common script for all pages-->
    <script src="js/common-scripts.js"></script>

  </body>

<!-- Mirrored from thevectorlab.net/flatlab/dynamic_table.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Nov 2014 04:52:22 GMT -->
</html>
