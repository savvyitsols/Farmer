<?php ob_start();
session_start();
error_reporting(0);
include "../config.php";
include "secure.php";
include "pageing.php";
extract($_POST);
extract($_GET);
$count_users=mysqli_num_rows(mysqli_query($connect,"SELECT * FROM `user`"));		
$count_farmtype=mysqli_num_rows(mysqli_query($connect,"SELECT * FROM `farmtype`"));
$count_farmitem=mysqli_num_rows(mysqli_query($connect,"SELECT * FROM `farmitem`"));	
$count_farming=mysqli_num_rows(mysqli_query($connect,"SELECT * FROM `farming`"));		
?>
<!DOCTYPE html>
<html lang="en">
  

<head>
    <meta charset="utf-8">
    
    <link rel="shortcut icon" href="img/favicon.html">

    <title>Farmer</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen"/>
    <link rel="stylesheet" href="css/owl.carousel.css" type="text/css">

      <!--right slidebar-->
      <link href="css/slidebars.css" rel="stylesheet">

    <!-- Custom styles for this template -->

    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />



    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

  <section id="container" >
      <!--header start-->
      <?php include "header.php"; ?>
      <!--header end-->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <?php include "sidemenu.php"; ?>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <!--state overview start-->
              <div class="row state-overview">
                  <div class="col-lg-3 col-sm-6">
                      <section class="panel">
                          <div class="symbol terques">
                              <i class="fa fa-user"></i>
                          </div>
                          <div class="value">
                            <a href="user.php">
                              <h1 >
                                 <?php echo $count_users; ?>
                              </h1>
                              <p>Users</p>
                              </a>
                          </div>
                      </section>
                  </div>
                  <div class="col-lg-3 col-sm-6">
                      <section class="panel">
                          <div class="symbol red">
                              <i class="fa fa-hospital-o"></i>
                          </div>
                          <div class="value">
                          <a href="farming.php">
                              <h1 >
                                  <?php echo $count_farming; ?>
                              </h1>
                              <p>Farming</p>
                              </a>
                          </div>
                      </section>
                  </div>
                  <div class="col-lg-3 col-sm-6">
                      <section class="panel">
                          <div class="symbol yellow">
                              <i class="fa  fa-users"></i>
                          </div>
                          <div class="value">
                          <a href="Farmingtype_List.php">
                              <h1 >
                                  <?php echo $count_farmtype; ?>
                              </h1>
                              <p>Farming Type</p>
                              </a>
                          </div>
                      </section>
                  </div>
                  <div class="col-lg-3 col-sm-6">
                      <section class="panel">
                          <div class="symbol blue">
                              <i class="fa fa-bar-chart-o"></i>
                          </div>
                          <div class="value">
                          <a href="Farmingitem_List.php">
                              <h1 class=" ">
                                  <?php echo $count_farmitem; ?>
                              </h1>
                              <p>Farming Item</p>
                              </a>
                          </div>
                      </section>
                  </div>
              </div>
              <!--state overview end-->

              
              
              
              

          </section>
      </section>
      <!--main content end-->


      <!--footer start-->
      <footer class="site-footer">
          <?php include "footer.php"; ?>
      </footer>
      <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="js/jquery.sparkline.js" type="text/javascript"></script>
    <script src="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="js/owl.carousel.js" ></script>
    <script src="js/jquery.customSelect.min.js" ></script>
    <script src="js/respond.min.js" ></script>

    <!--right slidebar-->
    <script src="js/slidebars.min.js"></script>

    <!--common script for all pages-->
    <script src="js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="js/sparkline-chart.js"></script>
    <script src="js/easy-pie-chart.js"></script>
    <script src="js/count.js"></script>

  <script>

      //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true,
			  autoPlay:true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>

<!-- Mirrored from thevectorlab.net/flatlab/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Nov 2014 04:49:40 GMT -->
</html>
