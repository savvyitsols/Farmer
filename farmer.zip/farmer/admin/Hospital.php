<?php ob_start();
session_start();
error_reporting(0);
include "../config.php";
include "secure.php";
include "pageing.php";
extract($_POST);
extract($_GET);
$date=date('Y-m-d H:i:s');
if(isset($_POST) && $_POST['Submit']=="Add")
{
	$date_encrypt=md5($date);
	
	$file_name=$date_encrypt.$_FILES["Hospital_Image"]["name"]; 
	
	$file_name=str_replace(" ","_",$file_name);
	
	$file_tmp_name=$_FILES["Hospital_Image"]["tmp_name"]; 
	
	$path = "../upload/".$file_name;
	
	$moveResult = move_uploaded_file($file_tmp_name, $path);
	
$insert=mysqli_query($connect,"INSERT INTO `hospital` (`hospital_name`, `About_hospital`, `Address_line1`, `Address_line2`, `Land_mark`, `City_id`, `Land_line_number_code`, `Land_line_number`, `website`, `emailid`, `Hospital_google_map_link`, `Hospital_Image`, `Insurances`, `Insurances_Info`, `Facilities`) VALUES ('$hospital_name' ,'$About_hospital' ,'$Address_line1' ,'$Address_line2' ,'$Land_mark' ,'$City_id' ,'$Land_line_number_code' ,'$Land_line_number' ,'$website' ,'$emailid' ,'$Hospital_google_map_link' ,'$Hospital_Image' ,'$Insurances' ,'$Insurances_Info' ,'$Facilities')");


	
	if($insert)
	{
		header("location:Hospital.php?insert=yes");
	}
	else
	{
		header("location:Hospital.php?insert=no");
	}
}
if(isset($_POST) && $_POST['Submit']=="Update")
{
	$update_query=mysqli_query($connect,"UPDATE `hospital` SET `hospital_name`='$hospital_name',`About_hospital`='$About_hospital',`Address_line1`='$Address_line1',`Address_line2`='$Address_line2',`Land_mark`='$Land_mark',`City_id`='$City_id',`Land_line_number_code`='$Land_line_number_code',`Land_line_number`='$Land_line_number',`website`='$website',`emailid`='$emailid',`Hospital_google_map_link`='$Hospital_google_map_link',`Insurances`='$Insurances',`Insurances_Info`='$Insurances_Info',`Facilities`='$Facilities' WHERE `hospital_id`='$id'");
	if(isset($update_query))
	{
		if($_FILES["Hospital_Image"]["name"]!='')
		{
			$date_encrypt=md5($date);
	
			$file_name=$date_encrypt.$_FILES["Hospital_Image"]["name"]; 
			
			$file_name=str_replace(" ","_",$file_name);
			
			$file_tmp_name=$_FILES["Hospital_Image"]["tmp_name"]; 
			
			$path = "../upload/".$file_name;
			
			$moveResult = move_uploaded_file($file_tmp_name, $path);
			$update_query=mysqli_query($connect,"UPDATE `hospital` SET `Hospital_Image`='$file_name' WHERE `hospital_id`='$id'");
		}
		header("location:Hospital.php?update=yes");
	}
	else
	{
		header("location:Hospital.php?update=no");
	}
}

?>
<!DOCTYPE html>
<html lang="en">
  

<head>
    <meta charset="utf-8">
    
    <link rel="shortcut icon" href="img/favicon.html">

    <title>Medserv.in</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />

    <!--dynamic table-->
    <link href="assets/advanced-datatable/media/css/demo_page.css" rel="stylesheet" />
    <link href="assets/advanced-datatable/media/css/demo_table.css" rel="stylesheet" />
    <link rel="stylesheet" href="assets/data-tables/DT_bootstrap.css" />
      <!--right slidebar-->
      <link href="css/slidebars.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
    <script type="text/javascript">
function delete1()
{
  if(window.confirm("Confirm delete"))
  {
  return true;
   }
 else
   return false;
}

function displayInsurance(s)
{
	
	if(s==1)
	{
		document.getElementById("ins_display").style.display='';
	}
	else
	{
		document.getElementById("ins_display").style.display='none';
	}
}
</script>
  </head>

  <body>

  <section id="container" class="">
      <!--header start-->
      <?php include "header.php"; ?>
      <!--header end-->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <?php include "sidemenu.php"; ?>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <!-- page start-->
              <?php
			  if(isset($_GET) && $_GET['action']=="add")
			  {
				  ?>
                  <div class="row">
                  <div class="col-lg-8">
                      <section class="panel">
                          <header class="panel-heading">
                             Add Hospital
                             <span class="tools pull-right">
                                
                                <a href="Hospital.php" style="color:#00F; font-weight:bold" >Back</a>
                             </span>
                          </header>
                          <div class="panel-body">
                              <form class="form-horizontal tasi-form" method="post" name="add" enctype="multipart/form-data">
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Original Hospital Name</label>
                                      <div class="col-sm-8">
                                          <input type="text" class="form-control" name="hospital_name" id="hospital_name" placeholder="Orginial Hospital Name "  required>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">About Hospital Name</label>
                                      <div class="col-sm-8">
                                         <textarea name="About_hospital" id="About_hospital"  required placeholder="About Hospital " class="form-control"></textarea>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 control-label col-lg-4" for="inputSuccess">Address</label>
                                      <div class="col-sm-8">
                                          <input type="text" class="form-control m-bot15" name="Address_line1" id="Address_line1" placeholder="Door No / Flat No / Plot No "  required>
                                          <input type="text" class="form-control m-bot15" name="Address_line2" id="Address_line2" placeholder="Street Name / Line Name"  required>
                                          <input type="text" class="form-control m-bot15" name="Land_mark" id="Land_mark" placeholder="Land Mark">
                                          <select name="City_id" id="City_id" class="form-control"  required>
                                            <option value=""> - Select City - </option>
                                            <?php
                                            $city_query=mysqli_query($connect,"SELECT * FROM `city`");
                                            while($city_query_row=mysqli_fetch_assoc($city_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $city_query_row["City_id"]; ?>'> <?php echo $city_query_row["City"]; ?> </option>
                                            <?php } ?>
                                          </select>
									  </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 control-label col-lg-4" for="inputSuccess">Contact Details</label>
                                      <div class="col-sm-4">
                                          <input type="text" class="form-control m-bot15" name="Land_line_number_code" id="Land_line_number_code" placeholder="STD Code"  required>
                                      </div>
                                      <div  class="col-sm-4">
                                      		<input type="text" class="form-control m-bot15" name="Land_line_number" id="Land_line_number" placeholder="Land Line Number"  required>
                                      </div>
                                      <label class="col-sm-4 control-label col-lg-4" for="inputSuccess">&nbsp;</label>
                                      <div class="col-sm-8">
                                          <input type="text" class="form-control m-bot15" name="website" id="website" placeholder="URL"  required>
                                          <input type="text" class="form-control m-bot15" name="emailid" id="emailid" placeholder=" Email Id"  required>
                                          <input type="text" class="form-control m-bot15" name="Hospital_google_map_link" id="Hospital_google_map_link" placeholder="Google Map URL"  required>
                                          
									  </div> 
									  
                                  </div>
                                  
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Is Hospital Providing any Insurance?</label>
                                      <div class="col-sm-4">
                                          <input type="radio" name="Insurances" value="1" onClick="displayInsurance(this.value);" >&nbsp;&nbsp;Yes
                                      </div>
                                      
                                        <div class="col-sm-4">
                                          <input type="radio" name="Insurances" value="0" onClick="displayInsurance(this.value);">&nbsp;&nbsp;No
                                      </div>  
                                  </div>
                                  
                                  
                                  <div class="form-group" id="ins_display" style="display:none">
                                      <label class="col-sm-4 col-sm-4 control-label">Insurances</label>
                                      <div class="col-sm-8">
                                          <input type="text" class="form-control" name="Insurances_Info" id="Insurances_Info" placeholder="Insurances">
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Facilities</label>
                                      <div class="col-sm-8">
                                          <input type="text" class="form-control" name="Facilities" id="Facilities" placeholder="Facilities"  required>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Hospital Image</label>
                                      <div class="col-sm-8">
                                          <input type="file" class="form-control" name="Hospital_Image" id="Hospital_Image"  required>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      
                                      <div class="col-sm-4">
                                          &nbsp;
                                      </div>
                                      <div class="col-sm-4">
                                          <input type="submit" name="Submit" value="Add" class="btn btn-success">
                                      </div>
                                      <div class="col-sm-4">
                                          &nbsp;
                                      </div>
                                  </div>
                                  
                                  
                                 
                                 
                              </form>
                          </div>
                      </section>
                   </div>
              </div>
                  
                  <?php
			  }
			  else if(isset($_GET) && $_GET['action']=="edit")
			  {
				  $edit=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `hospital` WHERE `hospital_id`='$id'"));
				  ?>
				  <div class="row">
                  <div class="col-lg-8">
                      <section class="panel">
                          <header class="panel-heading">
                             Edit Details Of <?php echo $edit['hospital_name']; ?>
                             <span class="tools pull-right">
                                
                                 <a href="Hospital.php" style="color:#00F; font-weight:bold" >Back</a>
                             </span>
                          </header>
                          <div class="panel-body">
                              <form class="form-horizontal tasi-form" method="post" name="add" enctype="multipart/form-data">
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Original Hospital Name</label>
                                      <div class="col-sm-8">
                                          <input type="text" class="form-control" name="hospital_name" id="hospital_name" placeholder="Orginial Hospital Name " value="<?php echo $edit['hospital_name']; ?>"  required>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">About Hospital Name</label>
                                      <div class="col-sm-8">
                                         <textarea name="About_hospital" id="About_hospital"  required placeholder="About Hospital " class="form-control"><?php echo $edit['About_hospital']; ?></textarea>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 control-label col-lg-4" for="inputSuccess">Address</label>
                                      <div class="col-sm-8">
                                          <input type="text"  required class="form-control m-bot15" name="Address_line1" id="Address_line1" placeholder="Door No / Flat No / Plot No " value="<?php echo $edit['Address_line1']; ?>">
                                          <input type="text"  required class="form-control m-bot15" name="Address_line2" id="Address_line2" placeholder="Street Name / Line Name" value="<?php echo $edit['Address_line2']; ?>">
                                          <input type="text"  required class="form-control m-bot15" name="Land_mark" id="Land_mark" placeholder="Land Mark" value="<?php echo $edit['Land_mark']; ?>">
                                          <select name="City_id"  required id="City_id" class="form-control">
                                            <option value=""> - Select City - </option>
                                            <?php
                                            $city_query=mysqli_query($connect,"SELECT * FROM `city`");
                                            while($city_query_row=mysqli_fetch_assoc($city_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $city_query_row["City_id"]; ?>' <?php if($edit['City_id']==$city_query_row['City_id']) { ?> selected <?php } ?>> <?php echo $city_query_row["City"]; ?> </option>
                                            <?php } ?>
                                          </select>
									  </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 control-label col-lg-4" for="inputSuccess">Contact Details</label>
                                      <div class="col-sm-4">
                                          <input type="text" class="form-control m-bot15" name="Land_line_number_code" id="Land_line_number_code"  required placeholder="STD Code" value="<?php echo $edit['Land_line_number_code']; ?>">
                                      </div>
                                      <div  class="col-sm-4">
                                      		<input  required type="text" class="form-control m-bot15" name="Land_line_number" id="Land_line_number" placeholder="Land Line Number" value="<?php echo $edit['Land_line_number']; ?>">
                                      </div>
                                      <label class="col-sm-4 control-label col-lg-4" for="inputSuccess">&nbsp;</label>
                                      <div class="col-sm-8">
                                          <input   required  type="text" class="form-control m-bot15" name="website" id="website" placeholder="URL" value="<?php echo $edit['website']; ?>">
                                          <input  required type="text" class="form-control m-bot15" name="emailid" id="emailid" placeholder=" Email Id" value="<?php echo $edit['emailid']; ?>">
                                          <input  required type="text" class="form-control m-bot15" name="Hospital_google_map_link" id="Hospital_google_map_link" placeholder="Google Map URL" value="<?php echo $edit['Hospital_google_map_link']; ?>">
                                          
									  </div> 
									  
                                  </div>
                                  
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Is Hospital Providing any Insurance?</label>
                                      <div class="col-sm-4">
                                          <input type="radio" name="Insurances" value="1" onClick="displayInsurance(this.value);"  <?php if($edit['Insurances']==1) { ?> checked <?php } ?> >&nbsp;&nbsp;Yes
                                      </div>
                                      
                                        <div class="col-sm-4">
                                          <input type="radio" name="Insurances" value="0" onClick="displayInsurance(this.value);" <?php if($edit['Insurances']==0) { ?> checked <?php } ?>>&nbsp;&nbsp;No
                                      </div>  
                                  </div>
                                  
                                 
                                  
                                  <div class="form-group" id="ins_display" <?php if($edit['Insurances']==0) { ?> style="display:none" <?php } ?> >
                                      <label class="col-sm-4 col-sm-4 control-label">Insurances</label>
                                      <div class="col-sm-8">
                                      	
                                          <input type="text" class="form-control" name="Insurances_Info" id="Insurances_Info" placeholder="Insurances" value="<?php echo $edit['Insurances_Info']; ?>">
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Facilities</label>
                                      <div class="col-sm-8">
                                          <input  required type="text" class="form-control" name="Facilities" id="Facilities" placeholder="Facilities" value="<?php echo $edit['Facilities']; ?>">
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Hospital Image</label>
                                      <div class="col-sm-8">
                                          <input type="file" class="form-control" name="Hospital_Image" id="Hospital_Image">
                                          <br>
<img src="../upload/<?php echo $edit['Hospital_Image']; ?>" width="60" height="60">
                                      </div>
                                  </div>
                                  <input type="hidden" name="id" value="<?php echo $id; ?>">
                                  <div class="form-group">
                                      
                                      <div class="col-sm-4">
                                          &nbsp;
                                      </div>
                                      <div class="col-sm-4">
                                          <input type="submit" name="Submit" value="Update" class="btn btn-success">
                                      </div>
                                      <div class="col-sm-4">
                                          &nbsp;
                                      </div>
                                  </div>
                                  
                                  
                                 
                                 
                              </form>
                          </div>
                      </section>
                   </div>
              </div>
                  
                  
                  <?php
			  }
			  else if(isset($_GET) && $_GET['action']=="more")
			  {
				  $edit=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `hospital` WHERE `hospital_id`='$id'"));
				  ?>
				  <div class="row">
                  <div class="col-lg-8">
                      <section class="panel">
                          <header class="panel-heading">
                             More Details Of <?php echo $edit['hospital_name']; ?>
                              <span class="tools pull-right">
                                
                                 <a href="Hospital.php" style="color:#00F; font-weight:bold" >Back</a>
                             </span>
                          </header>
                          <div class="panel-body">
                              <form class="form-horizontal tasi-form" method="post" name="add" enctype="multipart/form-data">
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Original Hospital Name</label>
                                      <div class="col-sm-8">
                                          <input type="text" class="form-control" name="hospital_name" id="hospital_name" placeholder="Orginial Hospital Name " readonly value="<?php echo $edit['hospital_name']; ?>">
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">About Hospital Name</label>
                                      <div class="col-sm-8">
                                         <textarea name="About_hospital" id="About_hospital" placeholder="About Hospital " class="form-control" readonly><?php echo $edit['About_hospital']; ?></textarea>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 control-label col-lg-4" for="inputSuccess">Address</label>
                                      <div class="col-sm-8">
                                          <input type="text" class="form-control m-bot15" name="Address_line1" id="Address_line1" placeholder="Door No / Flat No / Plot No " value="<?php echo $edit['Address_line1']; ?>" readonly>
                                          <input type="text" class="form-control m-bot15" name="Address_line2" id="Address_line2" placeholder="Street Name / Line Name" value="<?php echo $edit['Address_line2']; ?>" readonly>
                                          <input type="text" class="form-control m-bot15" name="Land_mark" id="Land_mark" placeholder="Land Mark" value="<?php echo $edit['Land_mark']; ?>" readonly>
                                          <select name="City_id" id="City_id" class="form-control">
                                            
                                            <?php
                                            $city_query=mysqli_query($connect,"SELECT * FROM `city` WHERE `City_id`='$edit[City_id]'");
                                            while($city_query_row=mysqli_fetch_assoc($city_query))
                                            {
                                            ?>
                                            
                                            <option value='<?php echo $city_query_row["City_id"]; ?>' <?php if($edit['City_id']==$city_query_row['City_id']) { ?> selected <?php } ?>> <?php echo $city_query_row["City"]; ?> </option>
                                            <?php } ?>
                                          </select>
									  </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 control-label col-lg-4" for="inputSuccess">Contact Details</label>
                                      <div class="col-sm-4">
                                          <input type="text" class="form-control m-bot15" name="Land_line_number_code" id="Land_line_number_code" placeholder="STD Code" value="<?php echo $edit['Land_line_number_code']; ?>" readonly>
                                      </div>
                                      <div  class="col-sm-4">
                                      		<input type="text" class="form-control m-bot15" name="Land_line_number" id="Land_line_number" placeholder="Land Line Number" value="<?php echo $edit['Land_line_number']; ?>" readonly>
                                      </div>
                                      <label class="col-sm-4 control-label col-lg-4" for="inputSuccess">&nbsp;</label>
                                      <div class="col-sm-8">
                                          <input type="text" class="form-control m-bot15" name="website" id="website" placeholder="URL" value="<?php echo $edit['website']; ?>" readonly>
                                          <input type="text" class="form-control m-bot15" name="emailid" id="emailid" placeholder=" Email Id" value="<?php echo $edit['emailid']; ?>" readonly>
                                          <input type="text" class="form-control m-bot15" name="Hospital_google_map_link" id="Hospital_google_map_link" placeholder="Google Map URL" value="<?php echo $edit['Hospital_google_map_link']; ?>" readonly>
                                          
									  </div> 
									  
                                  </div>
                                  
                                  
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Is Hospital Providing any Insurance?</label>
                                      <div class="col-sm-4">
                                          <?php if($edit['Insurances']==1) { ?> Yes <?php } else { ?>No <?php } ?> 
                                      </div>
                                      
                                      
                                  </div>
                                  
                                 
                                  
                                  <div class="form-group" id="ins_display" <?php if($edit['Insurances']==0) { ?> style="display:none" <?php } ?> >
                                      <label class="col-sm-4 col-sm-4 control-label">Insurances</label>
                                      <div class="col-sm-8">
                                      	
                                          <input type="text" class="form-control" name="Insurances_Info" id="Insurances_Info" placeholder="Insurances" value="<?php echo $edit['Insurances_Info']; ?>" readonly>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Facilities</label>
                                      <div class="col-sm-8">
                                          <input type="text" class="form-control" name="Facilities" id="Facilities" placeholder="Facilities" value="<?php echo $edit['Facilities']; ?>" readonly>
                                      </div>
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Hospital Image</label>
                                      <div class="col-sm-8">
                                        
<img src="../upload/<?php echo $edit['Hospital_Image']; ?>" width="60" height="60">
                                      </div>
                                  </div>
                                  
                              </form>
                          </div>
                      </section>
                   </div>
              </div>
                  
                  
                  <?php
			  }
			  else if(isset($_GET) && $_GET['action']=="delete")
			  {
				  	$deleted_query=mysqli_query($connect,"DELETE FROM `hospital` WHERE `hospital_id`='$id'");
					if(isset($deleted_query))
					{
						header("location:Hospital.php?delete=yes");
					}
					else
					{
						header("location:Hospital.php?delete=no");
					}
			  }
			  else
			  {
			  ?>
              <?php
				if(isset($insert))
				{
					?>
				
					<div class="row">
						<div class="col-lg-4">
						&nbsp;
						</div>
						<div class="col-lg-4" style="text-align:center">                       
							<?php
							if($insert=="yes")
							{
								?>
									<div class="alert alert-success  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Successfully Inserted.
									 </div>
                                <?php
							}
							else
							{
								?>
									<div class="alert alert-danger  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Insertion Operation Failed.
                                    </div>
                                <?php
							}
							?>
								 
						</div>
						<div class="col-lg-4">
						&nbsp;
						</div>
					</div>
					<?php 
					} 
					?>
                     <?php
				if(isset($update))
				{
					?>
				
					<div class="row">
						<div class="col-lg-4">
						&nbsp;
						</div>
						<div class="col-lg-4" style="text-align:center">                       
							<?php
							if($update=="yes")
							{
								?>
									<div class="alert alert-success  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Successfully Updated.
									 </div>
                                <?php
							}
							else
							{
								?>
									<div class="alert alert-danger  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Update Operation Failured.
                                    </div>
                                <?php
							}
							?>
								 
						</div>
						<div class="col-lg-4">
						&nbsp;
						</div>
					</div>
					<?php 
					} 
					?>
                     <?php
				if(isset($delete))
				{
					?>
				
					<div class="row">
						<div class="col-lg-4">
						&nbsp;
						</div>
						<div class="col-lg-4" style="text-align:center">                       
							<?php
							if($delete=="yes")
							{
								?>
									<div class="alert alert-success  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Successfully  Deleted.
									 </div>
                                <?php
							}
							else
							{
								?>
									<div class="alert alert-danger  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Delete Operation Failed.
                                    </div>
                                <?php
							}
							?>
								 
						</div>
						<div class="col-lg-4">
						&nbsp;
						</div>
					</div>
					<?php 
					} 
					?>
              <div class="row">
                <div class="col-sm-12">
              <section class="panel">
              <header class="panel-heading">
                  List Of Hospitals
             <span class="tools pull-right">
                <a href="javascript:;" class="fa fa-chevron-down"></a>
                <a href="javascript:;" class="fa fa-times"></a>
             </span>
              </header>
              <div class="panel-body">
              <div class="adv-table">
              <table  class="display table table-bordered table-striped" id="dynamic-table">
              <thead>
              <tr>
                    <th width="6%">S.No</th>
                    <th width="22%">Hospital Name</th>
                    <th width="13%">Land Mark</th>
                    <th width="20%">Land Line Number</th>
                    <th width="10%">website</th>
                    <th width="20%">Number of Doctors</th>
                    <th>More</th>
                    <th>Edit</th>
                    <th>Delete</th>
              </tr>
              </thead>
              <tbody>
              	<?php
				$sql_query=mysqli_query($connect,"SELECT * FROM `hospital` ORDER BY `hospital_id` asc");
				$total=mysqli_num_rows($sql_query);
				if($total==0)
				{
					?>
                    <tr>
                    	<td colspan="10" align="center">
                        	<font color="#FF0000"><strong>No Records</strong></font>
                        </td>
                    </tr>
                    <?php
				}
				else
				{
					$m=1;
					while($row=mysqli_fetch_array($sql_query))
					{	
						$count_doctors=mysqli_num_rows(mysqli_query($connect,"SELECT * FROM `doctor` WHERE `Primary_Hospital_Id`='$row[hospital_id]'"));		
						$count_secondary_doctors=mysqli_num_rows(mysqli_query($connect,"SELECT * FROM `hospital_doctor` WHERE `Hospital_id`='$row[hospital_id]'"));	
						?>
                        <tr>
                            <td><?php echo $m; ?></td>
                            <td><?php echo $row['hospital_name']; ?></td>
                            <td><?php echo $row['Land_mark']; ?></td>
                            <td><?php echo $row['Land_line_number_code']; ?>-<?php echo $row['Land_line_number']; ?></td>
                            <td><?php echo $row['website']; ?></td>
                            <td><?php echo $count_doctors+$count_secondary_doctors; ?></td>
                            <td><a href="Hospital.php?action=more&id=<?php echo $row['hospital_id']; ?>"><button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button></a></td>
                            <td><a href="Hospital.php?action=edit&id=<?php echo $row['hospital_id']; ?>"><button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button></a></td>
                            <td><a href="Hospital.php?action=delete&id=<?php echo $row['hospital_id']; ?>" onClick="return delete1();"><button class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i></button></a></td>
                        </tr>
                        <?php
						$m++;
					}
                	
				}
				?>
              </tbody>
              </table>
              </div>
              </div>
              </section>
              </div>
              </div>
              <?php 
			  }
			  ?>
              
              <!-- page end-->
          </section>
      </section>
      <!--main content end-->
      
      <!--footer start-->
      <footer class="site-footer" >
         <?php include "footer.php"; ?>
      </footer>
      <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->

    <script src="js/jquery.js"></script>
    <script src="js/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
    <script type="text/javascript" language="javascript" src="assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
    <script type="text/javascript" src="assets/data-tables/DT_bootstrap.js"></script>
    <script src="js/respond.min.js" ></script>

    <!--right slidebar-->
    <script src="js/slidebars.min.js"></script>

    <!--dynamic table initialization -->
    <script src="js/dynamic_table_init.js"></script>


    <!--common script for all pages-->
    <script src="js/common-scripts.js"></script>

  </body>

<!-- Mirrored from thevectorlab.net/flatlab/dynamic_table.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Nov 2014 04:52:22 GMT -->
</html>
