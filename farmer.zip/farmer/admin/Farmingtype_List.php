<?php ob_start();
session_start();
error_reporting(0);
include "../config.php";
include "secure.php";
include "pageing.php";
extract($_POST);
extract($_GET);
$date=date('Y-m-d H:i:s');
if(isset($_POST) && $_POST['Submit']=="Add")
{
	$date_encrypt=md5($date);
	
	$insert=mysqli_query($connect,"INSERT INTO `farmtype` (`farmtype`) VALUES ('$farmtype')");
	
	if($insert)
	{
		header("location:Farmingtype_List.php?insert=yes");
	}
	else
	{
		header("location:Farmingtype_List.php?insert=no");
	}
}
if(isset($_POST) && $_POST['Submit']=="Update")
{
	$update_query=mysqli_query($connect,"UPDATE `farmtype` SET `farmtype`='$farmtype' WHERE `farmType_id`='$id'");
  if(isset($update_query))
	{
			header("location:Farmingtype_List.php?update=yes");
	}
	else
	{
		header("location:Farmingtype_List.php?update=no");
	}
}
?>
<!DOCTYPE html>
<html lang="en">
  

<head>
    <meta charset="utf-8">
    
    <link rel="shortcut icon" href="img/favicon.html">

    <title>Farmer</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />

    <!--dynamic table-->
    <link href="assets/advanced-datatable/media/css/demo_page.css" rel="stylesheet" />
    <link href="assets/advanced-datatable/media/css/demo_table.css" rel="stylesheet" />
    <link rel="stylesheet" href="assets/data-tables/DT_bootstrap.css" />
      <!--right slidebar-->
      <link href="css/slidebars.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
    <script type="text/javascript">
function delete1()
{
  if(window.confirm("Confirm delete"))
  {
  return true;
   }
 else
   return false;
}

</script>
  </head>

  <body>

  <section id="container" class="">
      <!--header start-->
      <?php include "header.php"; ?>
      <!--header end-->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <?php include "sidemenu.php"; ?>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <!-- page start-->
              <?php
			  if(isset($_GET) && $_GET['action']=="add")
			  {
				  ?>
                  <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                             Add farming Type
                             <span class="tools pull-right">
                                
                                <a href="Farmingtype_List.php" style="color:#00F; font-weight:bold" >Back</a>
                             </span>
                          </header>
                          <div class="panel-body">
                              <form class="form-horizontal tasi-form" method="post" name="add" enctype="multipart/form-data">
                                  <div class="form-group">
                                      <label class="col-sm-2 col-sm-2 control-label">Farming Type</label>
                                      <div class="col-sm-10">
                                          <input class="form-control" type="text" name="farmtype" id="farmtype" placeholder="Farming Type" required/>
                                      </div>
                                  </div>
                                  
                                  
                                 <div class="form-group">
                                      
                                      <div class="col-sm-4">
                                          &nbsp;
                                      </div>
                                      <div class="col-sm-4">
                                          <input type="submit" name="Submit" value="Add" class="btn btn-success">
                                      </div>
                                      <div class="col-sm-4">
                                          &nbsp;
                                      </div>
                                  </div>
                                  
                              </form>
                          </div>
                      </section>
                   </div>
              </div>
                  
                  <?php
			  }
			  else if(isset($_GET) && $_GET['action']=="edit")
			  {
				  $edit=mysqli_fetch_array(mysqli_query($connect,"SELECT * FROM `farmtype` WHERE `farmType_id`='$id'"));
				  ?>
                  <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                             Edit Details of <?php echo $edit['farmtype'];  ?>
                             <span class="tools pull-right">
                                
                                <a href="Farmingtype_List.php" style="color:#00F; font-weight:bold" >Back</a>
                             </span>
                          </header>
                          <div class="panel-body">
                              <form class="form-horizontal tasi-form" method="post" name="add" enctype="multipart/form-data">
                                  <div class="form-group">
                                      <label class="col-sm-2 col-sm-2 control-label">Farming Type</label>
                                      <div class="col-sm-10">
                                          <input class="form-control" type="text" name="farmtype" id="farmtype" placeholder="Farming Type" required value="<?php echo $edit['farmtype']; ?>"/>
                                      </div>
                                  </div>
                                  
                                  
                                 <div class="form-group">
                                      
                                      <div class="col-sm-4">
                                          &nbsp;
                                      </div>
                                      <div class="col-sm-4">
                                          <input type="submit" name="Submit" value="Update" class="btn btn-success">
                                      </div>
                                      <div class="col-sm-4">
                                          &nbsp;
                                      </div>
                                  </div>
                                  <input type="hidden" name="id" value="<?php echo $id; ?>">
                              </form>
                          </div>
                      </section>
                   </div>
              </div>
                  
                  <?php
			  }
			  else if(isset($_GET) && $_GET['action']=="delete")
			  {
				 $deleted_query=mysqli_query($connect,"DELETE FROM `farmtype` WHERE `farmType_id`='$id'");
				if(isset($deleted_query))
				{
					header("location:Farmingtype_List.php?delete=yes");
				}
				else
				{
					header("location:Farmingtype_List.php?delete=no");
				}
			  }
			  else
			  {
			  ?>
              <?php
				if(isset($insert))
				{
					?>
				
					<div class="row">
						<div class="col-lg-4">
						&nbsp;
						</div>
						<div class="col-lg-4" style="text-align:center">                       
							<?php
							if($insert=="yes")
							{
								?>
									<div class="alert alert-success  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Successfully Inserted.
									 </div>
                                <?php
							}
							else
							{
								?>
									<div class="alert alert-danger  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Insertion Operation Failed.
                                    </div>
                                <?php
							}
							?>
								 
						</div>
						<div class="col-lg-4">
						&nbsp;
						</div>
					</div>
					<?php 
					} 
					?>
                     <?php
				if(isset($update))
				{
					?>
				
					<div class="row">
						<div class="col-lg-4">
						&nbsp;
						</div>
						<div class="col-lg-4" style="text-align:center">                       
							<?php
							if($update=="yes")
							{
								?>
									<div class="alert alert-success  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Successfully Updated.
									 </div>
                                <?php
							}
							else
							{
								?>
									<div class="alert alert-danger  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Update Operation Failured.
                                    </div>
                                <?php
							}
							?>
								 
						</div>
						<div class="col-lg-4">
						&nbsp;
						</div>
					</div>
					<?php 
					} 
					?>
                     <?php
				if(isset($delete))
				{
					?>
				
					<div class="row">
						<div class="col-lg-4">
						&nbsp;
						</div>
						<div class="col-lg-4" style="text-align:center">                       
							<?php
							if($delete=="yes")
							{
								?>
									<div class="alert alert-success  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Successfully  Deleted.
									 </div>
                                <?php
							}
							else
							{
								?>
									<div class="alert alert-danger  fade in">
										<button data-dismiss="alert" class="close close-sm" type="button">
										  <i class="fa fa-times"></i>
										</button>
										Delete Operation Failed.
                                    </div>
                                <?php
							}
							?>
								 
						</div>
						<div class="col-lg-4">
						&nbsp;
						</div>
					</div>
					<?php 
					} 
					?>
              <div class="row">
                <div class="col-sm-12">
              <section class="panel">
              <header class="panel-heading">
                  List Of Farming Types
             <span class="tools pull-right">
                <a href="javascript:;" class="fa fa-chevron-down"></a>
                <a href="javascript:;" class="fa fa-times"></a>
             </span>
              </header>
              <div class="panel-body">
              <div class="adv-table">
              <table  class="display table table-bordered table-striped" id="dynamic-table">
              <thead>
              <tr>
                    <th width="6%">S.No</th>
                    <th width="22%">Farming Type</th>
                    <th width="7%">Edit</th>
                    <th width="7%">Delete</th>
              </tr>
              </thead>
              <tbody>
              	<?php
				$sql_query=mysqli_query($connect,"SELECT * FROM `farmtype`");
				$total=mysqli_num_rows($sql_query);
				if($total==0)
				{
					?>
                    <tr>
                    	<td colspan="10" align="center">
                        	<font color="#FF0000"><strong>No Records</strong></font>
                        </td>
                    </tr>
                    <?php
				}
				else
				{
					$m=1;
					while($row=mysqli_fetch_array($sql_query))
					{		
						
						?>
                        <tr>
                            <td><?php echo $m; ?></td>
                           <td><?php echo $row['farmtype']; ?></td>
                           
                           <td><a href="Farmingtype_List.php?action=edit&id=<?php echo $row['farmType_id']; ?>"><button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button></a></td>
                            <td><a href="Farmingtype_List.php?action=delete&id=<?php echo $row['farmType_id']; ?>" onClick="return delete1();"><button class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i></button></a></td>
                        </tr>
                        <?php
						$m++;
					}
                	
				}
				?>
              </tbody>
              </table>
              </div>
              </div>
              </section>
              </div>
              </div>
              <?php 
			  }
			  ?>
              
              <!-- page end-->
          </section>
      </section>
      <!--main content end-->
      
      <!--footer start-->
      <footer class="site-footer" >
         <?php include "footer.php"; ?>
      </footer>
      <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->

    <script src="js/jquery.js"></script>
    <script src="js/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
    <script type="text/javascript" language="javascript" src="assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
    <script type="text/javascript" src="assets/data-tables/DT_bootstrap.js"></script>
    <script src="js/respond.min.js" ></script>

    <!--right slidebar-->
    <script src="js/slidebars.min.js"></script>

    <!--dynamic table initialization -->
    <script src="js/dynamic_table_init.js"></script>


    <!--common script for all pages-->
    <script src="js/common-scripts.js"></script>

  </body>

<!-- Mirrored from thevectorlab.net/flatlab/dynamic_table.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Nov 2014 04:52:22 GMT -->
</html>
