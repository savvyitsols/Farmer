<?php
include "../config.php";
extract($_POST);
extract($_GET);
$sql=mysqli_query($connect,"SELECT * FROM `state` WHERE `Country_Id`='$Country_Id'");

?>
<select name="State_Id" id="State_Id" class="form-control" required>
<option value=""> - Select State - </option>
<?php

while($sql_row=mysqli_fetch_assoc($sql))
{
?>

<option value='<?php echo $sql_row["State_id"]; ?>'> <?php echo $sql_row["State"]; ?> </option>
<?php } ?>
</select>